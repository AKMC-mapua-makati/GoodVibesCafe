<?php
// =============================================
// DATABASE CONFIGURATION
// =============================================
// Detects environment automatically.
// - Local XAMPP: uses root@localhost (no password)
// - InfinityFree: uses your hosting credentials
// =============================================

if (getenv('INFINITYFREE') || file_exists(__DIR__ . '/.env_infinityfree')) {
    // ── InfinityFree Credentials ──────────────────
    // Replace these with your actual values from
    // InfinityFree Control Panel > MySQL Databases
    // ──────────────────────────────────────────────
    $host = "sql210.infinityfree.com";
    $user = "if0_41364967";
    $pass = "GoodVibesCafe";
    $db   = "if0_41364967_goodvibescafe";
} else {
    // ── Local XAMPP Development ───────────────────
    $host = "localhost";
    $user = "root";
    $pass = "Makoto2026";
    $db   = "goodvibescafe";
}

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>