<?php
if(session_status() === PHP_SESSION_NONE){
    session_start();
}

// Dynamic base path: /GoodVibesCafe on XAMPP, empty on InfinityFree
$basePath = rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'])), '/\\');

$currentPage = basename($_SERVER['PHP_SELF'], '.php');
$userName = $_SESSION['user']['name'] ?? 'User';
$userRole = $_SESSION['user']['role'] ?? 'staff';
$isOwner = strtolower($userRole) === 'owner';

// Nav items based on role
$navItems = [
    ['name' => 'Dashboard', 'id' => 'dashboard'],
    ['name' => 'Transactions', 'id' => 'transactions'],
    ['name' => 'Ingredients', 'id' => 'ingredients'],
];

// Owner-only pages
if($isOwner){
    $navItems[] = ['name' => 'Products', 'id' => 'products'];
    $navItems[] = ['name' => 'Recipes', 'id' => 'recipes'];
    $navItems[] = ['name' => 'Categories', 'id' => 'categories'];
    $navItems[] = ['name' => 'Users', 'id' => 'users'];
    $navItems[] = ['name' => 'Logs', 'id' => 'logs'];
}
?>

<aside class="h-screen bg-[#fffdf9] border-r border-[#e8e0d4] flex flex-col sticky top-0 z-20 w-56">

    <!-- Logo -->
    <div class="h-20 flex items-center px-4 border-b border-[#e8e0d4]">
        <div class="flex items-center gap-3">
            <img src="<?= $basePath ?>/assets/images/pasted-image.jpg" alt="Logo"
                 class="w-12 h-12 rounded-full object-cover shadow-sm border border-[#e8e0d4]"/>
            <div class="flex flex-col">
                <span class="font-bold text-sm text-gray-900">Good Vibes Cafe</span>
                <span class="text-[10px] font-medium text-amber-700">At The Deck</span>
            </div>
        </div>
    </div>

    <!-- Navigation -->
    <nav class="flex-1 py-6 px-3 space-y-1 overflow-y-auto">
        <?php foreach($navItems as $item):
            $isActive = $currentPage === $item['id'];
        ?>
        <a href="../pages/<?= $item['id'] ?>.php"
           class="w-full flex items-center p-3 rounded-xl transition-all duration-200 <?= $isActive ? 'bg-amber-50 text-amber-700 shadow-sm' : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900' ?>">
            <span><?= $item['name'] ?></span>
        </a>
        <?php endforeach; ?>
    </nav>

    <!-- Footer -->
    <div class="p-4 border-t border-gray-100 space-y-2">
        <div class="px-2 pb-2">
            <p class="text-sm font-medium text-gray-800"><?= htmlspecialchars($userName) ?></p>
            <p class="text-xs text-gray-400 capitalize"><?= htmlspecialchars($userRole) ?></p>
        </div>
        <a href="../actions/logout.php"
           class="w-full flex items-center p-2 rounded-lg text-gray-400 hover:bg-red-50 hover:text-red-600 transition-colors">
            <span>Sign Out</span>
        </a>
    </div>

</aside>