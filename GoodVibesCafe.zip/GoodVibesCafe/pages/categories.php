<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
// Owner only
if (strtolower($_SESSION['user']['role'] ?? 'staff') !== 'owner') {
    header("Location: dashboard.php");
    exit();
}
$currentPage = 'categories';
require_once '../config/db.php';

$result = mysqli_query($conn, "SELECT * FROM categories ORDER BY id DESC");
$categories = [];
while ($row = mysqli_fetch_assoc($result)) {
    $categories[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Categories | Good Vibes Cafe</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="flex bg-[#f5f0e8] min-h-screen">

<?php include '../includes/sidebar.php'; ?>

<div class="flex-1 p-6">

<header class="flex items-center justify-between mb-6">
    <h1 class="text-2xl font-bold text-gray-900">Categories</h1>
    <button onclick="document.getElementById('addModal').classList.remove('hidden')"
            class="bg-amber-600 hover:bg-amber-700 text-white px-4 py-2 rounded-lg">
        + Add Category
    </button>
</header>

<!-- ALERT BOX -->
<?php if (isset($_GET['error']) || isset($_GET['success'])): ?>
<div id="alertBox" class="mb-4 p-3 rounded-lg border flex items-center justify-between
    <?php
        if (isset($_GET['error']) && $_GET['error'] === 'duplicate') echo 'bg-red-100 border-red-300 text-red-700';
        elseif (isset($_GET['error']) && $_GET['error'] === 'linked') echo 'bg-yellow-100 border-yellow-300 text-yellow-700';
        elseif (isset($_GET['success'])) echo 'bg-green-100 border-green-300 text-green-700';
    ?>">
    
    <span>
        <?php
            if (isset($_GET['error']) && $_GET['error'] === 'duplicate') echo '❌ Category already exists.';
            elseif (isset($_GET['error']) && $_GET['error'] === 'linked') echo '⚠ Cannot delete. Category is linked to products.';
            elseif (isset($_GET['success']) && $_GET['success'] === 'added') echo '✅ Category added successfully.';
            elseif (isset($_GET['success']) && $_GET['success'] === 'updated') echo '✏ Category updated successfully.';
            elseif (isset($_GET['success']) && $_GET['success'] === 'deleted') echo '🗑 Category deleted successfully.';
        ?>
    </span>

    <button onclick="closeAlert()" class="ml-4 text-xl leading-none font-bold hover:opacity-70">
        &times;
    </button>
</div>
<?php endif; ?>

<!-- Table -->
<div class="overflow-x-auto">
<table class="min-w-full bg-white rounded-xl border border-[#e8e0d4]">
<thead class="bg-[#f5f0e8]">
<tr>
<th class="px-4 py-2 border-b">ID</th>
<th class="px-4 py-2 border-b">Name</th>
<th class="px-4 py-2 border-b">Actions</th>
</tr>
</thead>
<tbody>
<?php foreach($categories as $c): ?>
<tr class="text-center border-b">
<td class="px-4 py-2"><?= $c['id'] ?></td>
<td class="px-4 py-2"><?= htmlspecialchars($c['name']) ?></td>
<td class="px-4 py-2 space-x-2">

<button onclick="openEditModal(<?= $c['id'] ?>,'<?= htmlspecialchars($c['name']) ?>')"
        class="bg-blue-500 hover:bg-blue-600 text-white px-2 py-1 rounded">Edit</button>

<form action="../actions/category_crud.php" method="POST" class="inline">
<input type="hidden" name="action" value="delete">
<input type="hidden" name="id" value="<?= $c['id'] ?>">
<button type="submit" onclick="return confirm('Delete this category?')"
        class="bg-red-500 hover:bg-red-600 text-white px-2 py-1 rounded">Delete</button>
</form>

</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
</div>

<!-- Add Modal -->
<div id="addModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
<form action="../actions/category_crud.php" method="POST" class="bg-white p-6 rounded-xl w-96">
<h2 class="text-lg font-bold mb-4">Add Category</h2>
<input type="hidden" name="action" value="create">

<div class="mb-2">
<label>Name</label>
<input type="text" name="name" required class="w-full border rounded px-2 py-1">
</div>

<div class="flex justify-end space-x-2 mt-4">
<button type="button" onclick="document.getElementById('addModal').classList.add('hidden')"
        class="px-3 py-1 rounded border">Cancel</button>
<button type="submit" class="bg-amber-600 hover:bg-amber-700 text-white px-3 py-1 rounded">Add</button>
</div>
</form>
</div>

<!-- Edit Modal -->
<div id="editModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
<form action="../actions/category_crud.php" method="POST" class="bg-white p-6 rounded-xl w-96">
<h2 class="text-lg font-bold mb-4">Edit Category</h2>
<input type="hidden" name="action" value="update">
<input type="hidden" name="id" id="edit_id">

<div class="mb-2">
<label>Name</label>
<input type="text" name="name" id="edit_name" required class="w-full border rounded px-2 py-1">
</div>

<div class="flex justify-end space-x-2 mt-4">
<button type="button" onclick="document.getElementById('editModal').classList.add('hidden')"
        class="px-3 py-1 rounded border">Cancel</button>
<button type="submit" class="bg-amber-600 hover:bg-amber-700 text-white px-3 py-1 rounded">Update</button>
</div>
</form>
</div>

<script>
function openEditModal(id,name){
document.getElementById('edit_id').value=id;
document.getElementById('edit_name').value=name;
document.getElementById('editModal').classList.remove('hidden');
}

function closeAlert(){
document.getElementById('alertBox')?.remove();
}

// Auto-hide alert
setTimeout(()=>closeAlert(),4000);
</script>

</body>
</html>