<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

// Only owner can access
$userRole = strtolower($_SESSION['user']['role'] ?? 'staff');
if ($userRole !== 'owner') {
    header("Location: dashboard.php");
    exit();
}

$currentPage = 'users';
require_once '../config/db.php';

// Fetch users
$result = mysqli_query($conn, "SELECT * FROM users ORDER BY id DESC");
$users = [];
while ($row = mysqli_fetch_assoc($result)) {
    $users[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Users | Good Vibes Cafe</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="flex bg-[#f5f0e8] min-h-screen">

<?php include '../includes/sidebar.php'; ?>

<div class="flex-1 p-6">
    <header class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-2xl font-bold text-gray-900">User Management</h1>
            <p class="text-gray-500 mt-1">Manage system access and roles</p>
        </div>
        <button onclick="document.getElementById('addModal').classList.remove('hidden')"
                class="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg">Add User</button>
    </header>

    <div class="bg-[#fffdf9] rounded-2xl shadow-sm border border-[#e8e0d4] overflow-hidden">
        <table class="w-full text-left border-collapse">
            <thead>
                <tr class="bg-[#f5f0e8]/50 border-b border-[#e8e0d4]">
                    <th class="py-4 px-6 text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
                    <th class="py-4 px-6 text-xs font-medium text-gray-500 uppercase tracking-wider text-center">Role</th>
                    <th class="py-4 px-6 text-xs font-medium text-gray-500 uppercase tracking-wider text-center">Status</th>
                    <th class="py-4 px-6 text-xs font-medium text-gray-500 uppercase tracking-wider text-right">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-[#e8e0d4]/50">
                <?php foreach ($users as $user): ?>
                    <tr class="text-center">
                        <td class="py-4 px-6 flex items-center gap-3">
                            <div class="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center font-medium text-amber-700">
                                <?= strtoupper(substr($user['name'],0,1)) ?>
                            </div>
                            <div class="text-left">
                                <p class="font-medium text-gray-900"><?= htmlspecialchars($user['name']) ?></p>
                                <p class="text-xs text-gray-500"><?= htmlspecialchars($user['email']) ?></p>
                            </div>
                        </td>
                        <td class="py-4 px-6">
                            <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium capitalize
                            <?= strtolower($user['role']) === 'owner' ? 'bg-purple-50 text-purple-700 border border-purple-100' : 'bg-blue-50 text-blue-700 border border-blue-100' ?>">
                                <?= htmlspecialchars($user['role']) ?>
                            </span>
                        </td>
                        <td class="py-4 px-6">
                            <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium
                            <?= $user['status'] === 'Active' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'bg-gray-100 text-gray-600 border border-gray-200' ?>">
                                <?= $user['status'] ?>
                            </span>
                        </td>
                        <td class="py-4 px-6 text-right flex justify-end gap-2">
                            <button onclick="openEditModal('<?= $user['id'] ?>','<?= htmlspecialchars($user['name']) ?>','<?= htmlspecialchars($user['email']) ?>','<?= $user['role'] ?>','<?= $user['status'] ?>')"
                                class="p-2 bg-blue-500 hover:bg-blue-600 text-white rounded">Edit</button>
                            <form action="../actions/user_crud.php" method="POST" class="inline">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?= $user['id'] ?>">
                                <button type="submit" onclick="return confirm('Delete this user?')" class="p-2 bg-red-500 hover:bg-red-600 text-white rounded">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add User Modal -->
<div id="addModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-30">
    <form action="../actions/user_crud.php" method="POST" class="bg-white p-6 rounded-xl w-96">
        <h2 class="text-lg font-bold mb-4">Add User</h2>
        <input type="hidden" name="action" value="create">
        <div class="mb-2"><label class="text-sm font-medium text-gray-700">Name</label><input type="text" name="name" required class="w-full border rounded px-2 py-1 mt-1"></div>
        <div class="mb-2"><label class="text-sm font-medium text-gray-700">Email</label><input type="email" name="email" required class="w-full border rounded px-2 py-1 mt-1"></div>
        <div class="mb-2"><label class="text-sm font-medium text-gray-700">Password</label><input type="password" name="password" required class="w-full border rounded px-2 py-1 mt-1"></div>
        <input type="hidden" name="role" value="staff">
        <div class="mb-2">
            <label class="text-sm font-medium text-gray-700">Status</label>
            <select name="status" required class="w-full border rounded px-2 py-1 mt-1">
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
            </select>
        </div>
        <div class="flex justify-end gap-2 mt-4">
            <button type="button" onclick="document.getElementById('addModal').classList.add('hidden')"
                    class="px-3 py-1 rounded border">Cancel</button>
            <button type="submit" class="bg-amber-600 hover:bg-amber-700 text-white px-3 py-1 rounded">Add</button>
        </div>
    </form>
</div>

<!-- Edit User Modal -->
<div id="editModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-30">
    <form action="../actions/user_crud.php" method="POST" class="bg-white p-6 rounded-xl w-96">
        <h2 class="text-lg font-bold mb-4">Edit User</h2>
        <input type="hidden" name="action" value="update">
        <input type="hidden" name="id" id="edit_id">
        <div class="mb-2"><label class="text-sm font-medium text-gray-700">Name</label><input type="text" name="name" id="edit_name" required class="w-full border rounded px-2 py-1 mt-1"></div>
        <div class="mb-2"><label class="text-sm font-medium text-gray-700">Email</label><input type="email" name="email" id="edit_email" required class="w-full border rounded px-2 py-1 mt-1"></div>
        <div class="mb-2"><label class="text-sm font-medium text-gray-700">Password (leave blank to keep)</label><input type="password" name="password" id="edit_password" class="w-full border rounded px-2 py-1 mt-1"></div>
        <div class="mb-2">
            <label class="text-sm font-medium text-gray-700">Role</label>
            <select name="role" id="edit_role" required class="w-full border rounded px-2 py-1 mt-1 bg-gray-50 pointer-events-none" tabindex="-1">
                <option value="staff">Staff</option>
                <option value="owner">Owner</option>
            </select>
            <p class="text-xs text-gray-500 mt-1">Roles cannot be changed dynamically.</p>
        </div>
        <div class="mb-2">
            <label class="text-sm font-medium text-gray-700">Status</label>
            <select name="status" id="edit_status" required class="w-full border rounded px-2 py-1 mt-1">
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
            </select>
        </div>
        <div class="flex justify-end gap-2 mt-4">
            <button type="button" onclick="document.getElementById('editModal').classList.add('hidden')"
                    class="px-3 py-1 rounded border">Cancel</button>
            <button type="submit" class="bg-amber-600 hover:bg-amber-700 text-white px-3 py-1 rounded">Update</button>
        </div>
    </form>
</div>

<script>
function openEditModal(id,name,email,role,status){
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_name').value = name;
    document.getElementById('edit_email').value = email;
    document.getElementById('edit_role').value = role;
    document.getElementById('edit_status').value = status;
    document.getElementById('edit_password').value = '';
    document.getElementById('editModal').classList.remove('hidden');
}
</script>

</body>
</html>