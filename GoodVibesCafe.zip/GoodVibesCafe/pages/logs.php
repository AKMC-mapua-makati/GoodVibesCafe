<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

// Owner only
$userRole = strtolower($_SESSION['user']['role'] ?? 'staff');
if ($userRole !== 'owner') {
    header("Location: dashboard.php");
    exit();
}

$currentPage = 'logs';
require_once '../config/db.php';

// Filters
$dateFrom = $_GET['date_from'] ?? '';
$dateTo = $_GET['date_to'] ?? '';
$search = $_GET['search'] ?? '';
$categoryIds = $_GET['categories'] ?? []; // Now an array from checkboxes

// Fetch all categories for the dropdown
$catResult = mysqli_query($conn, "SELECT id, name FROM categories ORDER BY name ASC");
$categories = [];
while ($catRow = mysqli_fetch_assoc($catResult)) {
    $categories[] = $catRow;
}

$where = [];
if ($dateFrom) $where[] = "DATE(o.created_at) >= '" . mysqli_real_escape_string($conn, $dateFrom) . "'";
if ($dateTo) $where[] = "DATE(o.created_at) <= '" . mysqli_real_escape_string($conn, $dateTo) . "'";
if ($search) {
    $s = mysqli_real_escape_string($conn, $search);
    $where[] = "(o.product_name LIKE '%$s%' OR o.processed_by LIKE '%$s%')";
}
if (!empty($categoryIds) && is_array($categoryIds)) {
    // Sanitize and create IN clause
    $safeIds = array_map(function($id) use ($conn) {
        return (int) mysqli_real_escape_string($conn, $id);
    }, $categoryIds);
    $inString = implode(',', $safeIds);
    $where[] = "p.category_id IN ($inString)";
}

$whereClause = count($where) > 0 ? "WHERE " . implode(' AND ', $where) : "";

// Fetch logs with JOIN to products to enable category filtering
$query = "
    SELECT 
        o.id, o.product_name, o.quantity, o.unit_price, o.total_price, 
        o.customization_notes, o.processed_by, o.created_at, p.category_id 
    FROM order_logs o 
    LEFT JOIN products p ON o.product_id = p.id 
    $whereClause 
    ORDER BY o.created_at DESC
";
$result = mysqli_query($conn, $query);
$logs = [];
$totalSales = 0;
while ($row = mysqli_fetch_assoc($result)) {
    $logs[] = $row;
    $totalSales += $row['total_price'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Logs | Good Vibes Cafe</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="flex bg-[#f5f0e8] min-h-screen">

<?php include '../includes/sidebar.php'; ?>

<div class="flex-1 p-6 flex flex-col h-screen overflow-hidden">
    <header class="mb-6">
        <h1 class="text-2xl font-bold text-gray-900">Order Logs</h1>
        <p class="text-gray-500 mt-1">View transaction history and export reports</p>
    </header>

    <!-- Summary Cards -->
    <div class="grid grid-cols-2 gap-4 mb-6">
        <div class="bg-white p-5 rounded-2xl border border-[#e8e0d4] flex items-center gap-4">
            <div class="w-12 h-12 rounded-xl bg-amber-100 flex items-center justify-center text-amber-600 text-xl">📄</div>
            <div>
                <p class="text-xs text-gray-500 font-medium uppercase tracking-wider">Total Records</p>
                <h3 class="text-2xl font-bold text-gray-900 mb-0 leading-none"><?= count($logs) ?></h3>
            </div>
        </div>
        <div class="bg-white p-5 rounded-2xl border border-[#e8e0d4] flex items-center gap-4">
            <div class="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center text-green-600 text-xl">₱</div>
            <div>
                <p class="text-xs text-gray-500 font-medium uppercase tracking-wider">Filtered Sales</p>
                <h3 class="text-2xl font-bold text-gray-900 mb-0 leading-none">₱<?= number_format($totalSales, 2) ?></h3>
            </div>
        </div>
    </div>

    <!-- Filters & Actions -->
    <div class="bg-white p-4 rounded-xl border border-[#e8e0d4] mb-6 flex flex-wrap gap-4 items-center justify-between">
        
        <form method="GET" class="flex flex-wrap gap-4 items-center">
            <!-- Search -->
            <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Search product or user..."
                   class="w-48 border border-[#e8e0d4] rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-amber-400 placeholder-gray-400">
            
            <!-- Dates -->
            <div class="flex items-center gap-2">
                <input type="date" name="date_from" value="<?= htmlspecialchars($dateFrom) ?>"
                       class="border border-[#e8e0d4] rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-amber-400 text-gray-600">
                <span class="text-gray-400 text-sm">to</span>
                <input type="date" name="date_to" value="<?= htmlspecialchars($dateTo) ?>"
                       class="border border-[#e8e0d4] rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-amber-400 text-gray-600">
            </div>

            <!-- Categories -->
            <div class="flex items-center gap-3 bg-gray-50 px-3 py-2 border border-gray-200 rounded-lg">
                <span class="text-xs font-medium text-gray-500 uppercase mr-1">Cat:</span>
                <?php foreach($categories as $cat): ?>
                    <label class="flex items-center gap-1.5 text-sm cursor-pointer hover:text-amber-700">
                        <input type="checkbox" name="categories[]" value="<?= $cat['id'] ?>" 
                               class="rounded border-gray-300 text-amber-600 focus:ring-amber-500"
                               <?= in_array($cat['id'], $categoryIds) ? 'checked' : '' ?>>
                        <span class="text-gray-700 leading-none"><?= htmlspecialchars($cat['name']) ?></span>
                    </label>
                <?php endforeach; ?>
            </div>

            <div class="flex items-center gap-2">
                <button type="submit" class="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white text-sm rounded-lg font-medium shadow-sm transition-colors">Filter</button>
                <?php if($search || $dateFrom || $dateTo || !empty($categoryIds)): ?>
                    <a href="logs.php" class="px-4 py-2 border border-[#e8e0d4] text-gray-600 text-sm rounded-lg hover:bg-gray-50 transition-colors">Clear</a>
                <?php endif; ?>
            </div>
        </form>

        <?php 
        // Build export query string preserving array structure
        $exportQuery = http_build_query([
            'start' => $dateFrom,
            'end' => $dateTo,
            'search' => $search,
            'categories' => $categoryIds
        ]);
        ?>
        <div class="flex items-center gap-2 shrink-0">
            <a href="../actions/download_logs.php?<?= $exportQuery ?>"
               target="_blank"
               class="bg-rose-600 text-white px-4 py-2.5 text-sm font-medium rounded-lg hover:bg-rose-700 transition-colors flex items-center gap-2 shadow-sm">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
                Print / PDF
            </a>
            <a href="../actions/download_logs.php?format=csv&<?= $exportQuery ?>"
               class="bg-emerald-600 text-white px-4 py-2.5 text-sm font-medium rounded-lg hover:bg-emerald-700 transition-colors flex items-center gap-2 shadow-sm">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                Export CSV
            </a>
        </div>
    </div>

    <!-- Logs Table -->
    <div class="bg-white rounded-xl border border-[#e8e0d4] overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-[#f5f0e8]/50 border-b border-[#e8e0d4]">
                        <th class="py-3 px-4 text-xs font-medium text-gray-500 uppercase">Date & Time</th>
                        <th class="py-3 px-4 text-xs font-medium text-gray-500 uppercase">Product</th>
                        <th class="py-3 px-4 text-xs font-medium text-gray-500 uppercase">Qty</th>
                        <th class="py-3 px-4 text-xs font-medium text-gray-500 uppercase">Unit Price</th>
                        <th class="py-3 px-4 text-xs font-medium text-gray-500 uppercase">Total</th>
                        <th class="py-3 px-4 text-xs font-medium text-gray-500 uppercase">Processed By</th>
                        <th class="py-3 px-4 text-xs font-medium text-gray-500 uppercase">Customization</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-[#e8e0d4]/50">
                    <?php if(empty($logs)): ?>
                    <tr>
                        <td colspan="7" class="py-8 text-center text-gray-400">No logs found</td>
                    </tr>
                    <?php else: ?>
                    <?php foreach($logs as $log): ?>
                    <tr class="hover:bg-[#faf7f2] transition-colors">
                        <td class="py-3 px-4 text-sm text-gray-600"><?= date("M d, Y h:i A", strtotime($log['created_at'])) ?></td>
                        <td class="py-3 px-4 text-sm font-medium text-gray-900"><?= htmlspecialchars($log['product_name']) ?></td>
                        <td class="py-3 px-4 text-sm text-gray-700"><?= $log['quantity'] ?></td>
                        <td class="py-3 px-4 text-sm text-gray-700">₱<?= number_format($log['unit_price'], 2) ?></td>
                        <td class="py-3 px-4 text-sm font-semibold text-amber-700">₱<?= number_format($log['total_price'], 2) ?></td>
                        <td class="py-3 px-4 text-sm text-gray-600"><?= htmlspecialchars($log['processed_by']) ?></td>
                        <td class="py-3 px-4 text-sm text-gray-500 max-w-xs">
                            <?php if($log['customization_notes']): ?>
                                <span class="inline-block bg-amber-50 text-amber-700 px-2 py-1 rounded text-xs"><?= htmlspecialchars($log['customization_notes']) ?></span>
                            <?php else: ?>
                                <span class="text-gray-300">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

</body>
</html>
