<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
// Owner only
if (strtolower($_SESSION['user']['role'] ?? 'staff') !== 'owner') {
    header("Location: dashboard.php");
    exit();
}
$currentPage = 'products';
require_once '../config/db.php';

// Find the Ingredient category ID
$ingCatRes = mysqli_query($conn, "SELECT id FROM categories WHERE LOWER(name) = 'ingredient'");
$ingCatRow = mysqli_fetch_assoc($ingCatRes);
$ingredientCategoryId = $ingCatRow ? (int)$ingCatRow['id'] : 0;

// Fetch products with computed stock from ingredients (exclude Ingredient category)
$productQuery = "
    SELECT p.id, p.name, c.name as category, p.price, p.category_id,
        COALESCE(
            (SELECT MIN(FLOOR(ing.stock / pi.quantity))
             FROM product_ingredients pi
             JOIN products ing ON pi.ingredient_id = ing.id
             WHERE pi.product_id = p.id),
            p.stock
        ) AS stock
    FROM products p
    JOIN categories c ON p.category_id = c.id
    WHERE LOWER(c.name) != 'ingredient'
    ORDER BY p.id DESC
";
$products = mysqli_query($conn, $productQuery);

// Fetch categories for dropdown (exclude Ingredient from add/edit)
$categoryResult = mysqli_query($conn, "SELECT * FROM categories WHERE LOWER(name) != 'ingredient'");
$categories = [];
while ($row = mysqli_fetch_assoc($categoryResult)) {
    $categories[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Products | Good Vibes Cafe</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="flex bg-[#f5f0e8] min-h-screen">

<?php include '../includes/sidebar.php'; ?>

<div class="flex-1 p-6">

<header class="flex items-center justify-between mb-6">
    <h1 class="text-2xl font-bold text-gray-900">Products</h1>
    <button onclick="document.getElementById('addModal').classList.remove('hidden')"
            class="bg-amber-600 hover:bg-amber-700 text-white px-4 py-2 rounded-lg">
        + Add Product
    </button>
</header>

<!-- ALERT BOX -->
<?php if (isset($_GET['error']) || isset($_GET['success'])): ?>
<div id="alertBox" class="mb-4 p-3 rounded-lg border flex items-center justify-between
    <?php
        if (isset($_GET['error']) && $_GET['error'] === 'duplicate') echo 'bg-red-100 border-red-300 text-red-700';
        elseif (isset($_GET['error']) && $_GET['error'] === 'linked') echo 'bg-yellow-100 border-yellow-300 text-yellow-700';
        elseif (isset($_GET['success'])) echo 'bg-green-100 border-green-300 text-green-700';
    ?>">
    
    <span>
        <?php
            if (isset($_GET['error']) && $_GET['error'] === 'duplicate') echo '❌ Product name already exists. Please choose a different name.';
            elseif (isset($_GET['error']) && $_GET['error'] === 'linked') echo '⚠ Cannot delete this product. It is linked to existing transactions.';
            elseif (isset($_GET['success']) && $_GET['success'] === 'added') echo '✅ Product added successfully.';
            elseif (isset($_GET['success']) && $_GET['success'] === 'updated') echo '✏ Product updated successfully.';
            elseif (isset($_GET['success']) && $_GET['success'] === 'deleted') echo '🗑 Product deleted successfully.';
        ?>
    </span>

    <button onclick="closeAlert()" class="ml-4 text-xl leading-none font-bold hover:opacity-70">
        &times;
    </button>
</div>
<?php endif; ?>

<!-- Products Table -->
<div class="overflow-x-auto">
    <table class="min-w-full bg-white rounded-xl border border-[#e8e0d4]">
        <thead class="bg-[#f5f0e8]">
            <tr>
                <th class="px-4 py-2 border-b">ID</th>
                <th class="px-4 py-2 border-b">Name</th>
                <th class="px-4 py-2 border-b">Category</th>
                <th class="px-4 py-2 border-b">Price</th>
                <th class="px-4 py-2 border-b">Stock</th>
                <th class="px-4 py-2 border-b">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($p = mysqli_fetch_assoc($products)): ?>
            <?php $isIngredient = ((int)$p['category_id'] === $ingredientCategoryId); ?>
            <tr class="text-center border-b">
                <td class="px-4 py-2"><?= $p['id'] ?></td>
                <td class="px-4 py-2"><?= htmlspecialchars($p['name']) ?></td>
                <td class="px-4 py-2">
                    <?php if ($isIngredient): ?>
                        <span class="bg-emerald-100 text-emerald-700 text-xs font-semibold px-2 py-1 rounded-full"><?= htmlspecialchars($p['category']) ?></span>
                    <?php else: ?>
                        <?= htmlspecialchars($p['category']) ?>
                    <?php endif; ?>
                </td>
                <td class="px-4 py-2">
                    <?php if ($isIngredient): ?>
                        <span class="text-gray-400 text-xs">—</span>
                    <?php else: ?>
                        <?= number_format($p['price'],2) ?>
                    <?php endif; ?>
                </td>
                <td class="px-4 py-2">
                    <?php if ($isIngredient): ?>
                        <span class="font-bold"><?= $p['stock'] ?></span>
                        <span class="text-xs text-gray-400">(raw)</span>
                    <?php else: ?>
                        <?= $p['stock'] ?>
                        <span class="text-xs text-gray-400">(from ingredients)</span>
                    <?php endif; ?>
                </td>
                <td class="px-4 py-2 space-x-2">
                    <button onclick="openEditModal(<?= $p['id'] ?>,'<?= htmlspecialchars(addslashes($p['name'])) ?>',<?= $p['category_id'] ?>,<?= $p['price'] ?>,<?= $p['stock'] ?>)"
                            class="bg-blue-500 hover:bg-blue-600 text-white px-2 py-1 rounded">Edit</button>

                    <form action="../actions/product_crud.php" method="POST" class="inline">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?= $p['id'] ?>">
                        <button type="submit" class="bg-red-500 hover:bg-red-600 text-white px-2 py-1 rounded"
                                onclick="return confirm('Delete this product?')">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
</div>

<!-- Add Modal -->
<div id="addModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
<form action="../actions/product_crud.php" method="POST" class="bg-white p-6 rounded-xl w-96">
<h2 class="text-lg font-bold mb-4">Add Product</h2>
<input type="hidden" name="action" value="create">

<div class="mb-2">
<label>Name</label>
<input type="text" name="name" required class="w-full border rounded px-2 py-1">
</div>

<div class="mb-2">
<label>Category</label>
<select name="category_id" id="add_category_id" required class="w-full border rounded px-2 py-1" onchange="toggleAddStock()">
<?php foreach($categories as $c): ?>
<option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
<?php endforeach; ?>
</select>
</div>

<div class="mb-2" id="add_price_field">
<label>Price</label>
<input type="number" step="0.01" name="price" value="0" class="w-full border rounded px-2 py-1">
</div>

<div class="mb-2 hidden" id="add_stock_field">
<label>Stock <span class="text-xs text-gray-400">(ingredient only)</span></label>
<input type="number" name="stock" value="0" class="w-full border rounded px-2 py-1">
</div>

<p class="text-xs text-gray-400 mb-2" id="add_stock_note">
    Stock is calculated from linked ingredients. Manage recipes on the Recipes page.
</p>

<div class="flex justify-end space-x-2 mt-4">
<button type="button" onclick="document.getElementById('addModal').classList.add('hidden')" class="px-3 py-1 rounded border">Cancel</button>
<button type="submit" class="bg-amber-600 hover:bg-amber-700 text-white px-3 py-1 rounded">Add</button>
</div>
</form>
</div>

<!-- Edit Modal -->
<div id="editModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
<form action="../actions/product_crud.php" method="POST" class="bg-white p-6 rounded-xl w-96">
<h2 class="text-lg font-bold mb-4">Edit Product</h2>
<input type="hidden" name="action" value="update">
<input type="hidden" name="id" id="edit_id">

<div class="mb-2">
<label>Name</label>
<input type="text" name="name" id="edit_name" required class="w-full border rounded px-2 py-1">
</div>

<div class="mb-2">
<label>Category</label>
<select name="category_id" id="edit_category_id" required class="w-full border rounded px-2 py-1" onchange="toggleEditStock()">
<?php foreach($categories as $c): ?>
<option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
<?php endforeach; ?>
</select>
</div>

<div class="mb-2" id="edit_price_field">
<label>Price</label>
<input type="number" step="0.01" name="price" id="edit_price" required class="w-full border rounded px-2 py-1">
</div>

<div class="mb-2 hidden" id="edit_stock_field">
<label>Stock <span class="text-xs text-gray-400">(ingredient only)</span></label>
<input type="number" name="stock" id="edit_stock" class="w-full border rounded px-2 py-1">
</div>

<p class="text-xs text-gray-400 mb-2 hidden" id="edit_stock_note">
    Stock is calculated from linked ingredients. Manage recipes on the Recipes page.
</p>

<div class="flex justify-end space-x-2 mt-4">
<button type="button" onclick="document.getElementById('editModal').classList.add('hidden')" class="px-3 py-1 rounded border">Cancel</button>
<button type="submit" class="bg-amber-600 hover:bg-amber-700 text-white px-3 py-1 rounded">Update</button>
</div>
</form>
</div>

<script>
const INGREDIENT_CAT_ID = <?= $ingredientCategoryId ?>;

function toggleAddStock() {
    const catId = parseInt(document.getElementById('add_category_id').value);
    const isIng = catId === INGREDIENT_CAT_ID;
    document.getElementById('add_stock_field').classList.toggle('hidden', !isIng);
    document.getElementById('add_stock_note').classList.toggle('hidden', isIng);
}

function toggleEditStock() {
    const catId = parseInt(document.getElementById('edit_category_id').value);
    const isIng = catId === INGREDIENT_CAT_ID;
    document.getElementById('edit_stock_field').classList.toggle('hidden', !isIng);
    document.getElementById('edit_stock_note').classList.toggle('hidden', isIng);
}

function openEditModal(id, name, cat, price, stock) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_name').value = name;
    document.getElementById('edit_category_id').value = cat;
    document.getElementById('edit_price').value = price;
    document.getElementById('edit_stock').value = stock;
    document.getElementById('editModal').classList.remove('hidden');
    toggleEditStock();
}

function closeAlert() {
    document.getElementById('alertBox')?.remove();
}

// Initialize add modal stock visibility
toggleAddStock();

// Auto close after 4 seconds
setTimeout(() => closeAlert(), 4000);
</script>

</body>
</html>