<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
// Owner only
if (strtolower($_SESSION['user']['role'] ?? 'staff') !== 'owner') {
    header("Location: dashboard.php");
    exit();
}
$currentPage = 'recipes';
require_once '../config/db.php';

// Fetch all products that are NOT ingredients for the main list
$productQuery = "
    SELECT p.id, p.name, c.name as category, p.price, p.stock, p.category_id
    FROM products p
    JOIN categories c ON p.category_id = c.id
    WHERE LOWER(c.name) != 'ingredient'
    ORDER BY p.id DESC
";
$products = mysqli_query($conn, $productQuery);

// Fetch all ingredients
$ingredientsQuery = "
    SELECT p.id, p.name 
    FROM products p
    JOIN categories c ON p.category_id = c.id
    WHERE LOWER(c.name) = 'ingredient'
    ORDER BY p.name ASC
";
$ingredientsRes = mysqli_query($conn, $ingredientsQuery);
$ingredients = [];
while ($row = mysqli_fetch_assoc($ingredientsRes)) {
    $ingredients[] = $row;
}

// Fetch existing product ingredients
$piQuery = "
    SELECT pi.id, pi.product_id, pi.quantity, i.name as ingredient_name
    FROM product_ingredients pi
    JOIN products i ON pi.ingredient_id = i.id
";
$piRes = mysqli_query($conn, $piQuery);
$productIngredients = [];
while ($row = mysqli_fetch_assoc($piRes)) {
    $product_id = $row['product_id'];
    if (!isset($productIngredients[$product_id])) {
        $productIngredients[$product_id] = [];
    }
    $productIngredients[$product_id][] = $row;
}

// Fetch existing extra ingredients
$eiQuery = "
    SELECT ei.id, ei.extra_id, ei.quantity, i.name as ingredient_name
    FROM extra_ingredients ei
    JOIN products i ON ei.ingredient_id = i.id
";
$eiRes = mysqli_query($conn, $eiQuery);
$extraIngredients = [];
while ($row = mysqli_fetch_assoc($eiRes)) {
    $extra_id = $row['extra_id'];
    if (!isset($extraIngredients[$extra_id])) {
        $extraIngredients[$extra_id] = [];
    }
    $extraIngredients[$extra_id][] = $row;
}

// Pre-defined POS extras based on existing frontend code
$posExtras = [
    ['id' => 'extra_shot', 'name' => 'Extra Shot'],
    ['id' => 'upsize', 'name' => 'Upsize'],
    ['id' => 'extra_rice', 'name' => 'Extra Rice'],
    ['id' => 'extra_sauce', 'name' => 'Extra Sauce']
];

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Recipes | Good Vibes Cafe</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="flex bg-[#f5f0e8] min-h-screen">

<?php include '../includes/sidebar.php'; ?>

<div class="flex-1 p-6 overflow-y-auto">

<header class="flex items-center justify-between mb-6">
    <h1 class="text-2xl font-bold text-gray-900">Recipes & Extras</h1>
    <p class="text-gray-500">Manage ingredients required for products and extras</p>
</header>

<!-- ALERT BOX -->
<?php if (isset($_GET['error']) || isset($_GET['success'])): ?>
<div id="alertBox" class="mb-4 p-3 rounded-lg border flex items-center justify-between
    <?php
        if (isset($_GET['error'])) echo 'bg-red-100 border-red-300 text-red-700';
        elseif (isset($_GET['success'])) echo 'bg-green-100 border-green-300 text-green-700';
    ?>">
    
    <span>
        <?php
            if (isset($_GET['error']) && $_GET['error'] === 'product_exists') echo '❌ This ingredient is already linked to the product.';
            elseif (isset($_GET['error']) && $_GET['error'] === 'extra_exists') echo '❌ This ingredient is already linked to the extra.';
            elseif (isset($_GET['success']) && $_GET['success'] === 'product_added') echo '✅ Ingredient added to product successfully.';
            elseif (isset($_GET['success']) && $_GET['success'] === 'product_removed') echo '🗑 Ingredient removed from product.';
            elseif (isset($_GET['success']) && $_GET['success'] === 'extra_added') echo '✅ Ingredient added to extra successfully.';
            elseif (isset($_GET['success']) && $_GET['success'] === 'extra_removed') echo '🗑 Ingredient removed from extra.';
        ?>
    </span>

    <button onclick="closeAlert()" class="ml-4 text-xl leading-none font-bold hover:opacity-70">
        &times;
    </button>
</div>
<?php endif; ?>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

    <!-- Products Recipes Section -->
    <div class="bg-white rounded-xl border border-[#e8e0d4] p-6 shadow-sm">
        <h2 class="text-xl font-bold text-gray-900 mb-4 border-b pb-2">Product Recipes</h2>
        
        <?php 
        mysqli_data_seek($products, 0);
        while ($p = mysqli_fetch_assoc($products)): 
        ?>
        <div class="mb-6 p-4 border border-gray-100 rounded-lg bg-gray-50">
            <div class="flex justify-between items-center mb-3">
                <div>
                    <h3 class="font-bold text-lg text-amber-800"><?= htmlspecialchars($p['name']) ?></h3>
                    <p class="text-sm text-gray-500"><?= htmlspecialchars($p['category']) ?></p>
                </div>
                <button onclick="openAddProductIngredientModal(<?= $p['id'] ?>, '<?= htmlspecialchars(addslashes($p['name'])) ?>')" 
                        class="px-3 py-1 bg-amber-600 hover:bg-amber-700 text-white text-sm rounded-md shadow-sm">
                    + Add Ingredient
                </button>
            </div>
            
            <?php if (isset($productIngredients[$p['id']])): ?>
                <ul class="space-y-2 mt-2 pl-2">
                <?php foreach($productIngredients[$p['id']] as $pi): ?>
                    <li class="flex justify-between items-center bg-white p-2 border rounded text-sm">
                        <span><?= $pi['quantity'] ?>x <strong><?= htmlspecialchars($pi['ingredient_name']) ?></strong></span>
                        <form action="../actions/recipe_crud.php" method="POST" class="inline">
                            <input type="hidden" name="action" value="remove_product_ingredient">
                            <input type="hidden" name="id" value="<?= $pi['id'] ?>">
                            <button type="submit" class="text-red-500 hover:text-red-700" onclick="return confirm('Remove this ingredient from the recipe?')">
                                Remove
                            </button>
                        </form>
                    </li>
                <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p class="text-sm text-gray-400 italic pl-2 mt-2">No ingredients mapped. Entire product stock will be deducted on sale.</p>
            <?php endif; ?>
        </div>
        <?php endwhile; ?>
    </div>

    <!-- Extras Recipes Section -->
    <div class="bg-white rounded-xl border border-[#e8e0d4] p-6 shadow-sm">
        <h2 class="text-xl font-bold text-gray-900 mb-4 border-b pb-2">Extra Modifier Recipes</h2>
        <p class="text-sm text-gray-500 mb-4">Map ingredients to POS menu extras (e.g. Extra Shot uses 1 Espresso Bean)</p>

        <?php foreach ($posExtras as $extra): ?>
        <div class="mb-6 p-4 border border-gray-100 rounded-lg bg-blue-50">
            <div class="flex justify-between items-center mb-3">
                <div>
                    <h3 class="font-bold text-lg text-blue-800"><?= htmlspecialchars($extra['name']) ?></h3>
                    <p class="text-xs text-gray-500">ID: <?= htmlspecialchars($extra['id']) ?></p>
                </div>
                <button onclick="openAddExtraIngredientModal('<?= $extra['id'] ?>', '<?= htmlspecialchars(addslashes($extra['name'])) ?>')" 
                        class="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-md shadow-sm">
                    + Add Ingredient
                </button>
            </div>
            
            <?php if (isset($extraIngredients[$extra['id']])): ?>
                <ul class="space-y-2 mt-2 pl-2">
                <?php foreach($extraIngredients[$extra['id']] as $ei): ?>
                    <li class="flex justify-between items-center bg-white p-2 border rounded text-sm">
                        <span><?= $ei['quantity'] ?>x <strong><?= htmlspecialchars($ei['ingredient_name']) ?></strong></span>
                        <form action="../actions/recipe_crud.php" method="POST" class="inline">
                            <input type="hidden" name="action" value="remove_extra_ingredient">
                            <input type="hidden" name="id" value="<?= $ei['id'] ?>">
                            <button type="submit" class="text-red-500 hover:text-red-700" onclick="return confirm('Remove this ingredient from the extra?')">
                                Remove
                            </button>
                        </form>
                    </li>
                <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p class="text-sm text-gray-400 italic pl-2 mt-2">No ingredients mapped to this extra.</p>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>

</div>

</div>

<!-- Modal: Add Product Ingredient -->
<div id="addProductIngredientModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <form action="../actions/recipe_crud.php" method="POST" class="bg-white p-6 rounded-xl w-96 shadow-lg">
        <h2 class="text-lg font-bold mb-2">Add Ingredient to Product</h2>
        <p class="text-sm text-amber-700 font-semibold mb-4" id="pi_product_name_display"></p>
        
        <input type="hidden" name="action" value="add_product_ingredient">
        <input type="hidden" name="product_id" id="pi_product_id">
        
        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-1">Select Ingredient</label>
            <select name="ingredient_id" required class="w-full border rounded-lg px-3 py-2 bg-gray-50 outline-none focus:ring-2 focus:ring-amber-500">
                <option value="">-- Choose Ingredient --</option>
                <?php foreach($ingredients as $ing): ?>
                    <option value="<?= $ing['id'] ?>"><?= htmlspecialchars($ing['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div class="mb-6">
            <label class="block text-sm font-medium text-gray-700 mb-1">Quantity to Deduct</label>
            <input type="number" name="quantity" min="1" value="1" required class="w-full border rounded-lg px-3 py-2 bg-gray-50 outline-none focus:ring-2 focus:ring-amber-500">
        </div>
        
        <div class="flex justify-end space-x-3 mt-4 pt-4 border-t">
            <button type="button" onclick="document.getElementById('addProductIngredientModal').classList.add('hidden')" class="px-4 py-2 rounded-lg border text-gray-600 hover:bg-gray-50">Cancel</button>
            <button type="submit" class="bg-amber-600 hover:bg-amber-700 text-white px-4 py-2 rounded-lg font-medium shadow-sm">Add Link</button>
        </div>
    </form>
</div>

<!-- Modal: Add Extra Ingredient -->
<div id="addExtraIngredientModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <form action="../actions/recipe_crud.php" method="POST" class="bg-white p-6 rounded-xl w-96 shadow-lg">
        <h2 class="text-lg font-bold mb-2">Add Ingredient to Extra</h2>
        <p class="text-sm text-blue-700 font-semibold mb-4" id="ei_extra_name_display"></p>
        
        <input type="hidden" name="action" value="add_extra_ingredient">
        <input type="hidden" name="extra_id" id="ei_extra_id">
        
        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-1">Select Ingredient</label>
            <select name="ingredient_id" required class="w-full border rounded-lg px-3 py-2 bg-gray-50 outline-none focus:ring-2 focus:ring-blue-500">
                <option value="">-- Choose Ingredient --</option>
                <?php foreach($ingredients as $ing): ?>
                    <option value="<?= $ing['id'] ?>"><?= htmlspecialchars($ing['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div class="mb-6">
            <label class="block text-sm font-medium text-gray-700 mb-1">Quantity to Deduct</label>
            <input type="number" name="quantity" min="1" value="1" required class="w-full border rounded-lg px-3 py-2 bg-gray-50 outline-none focus:ring-2 focus:ring-blue-500">
        </div>
        
        <div class="flex justify-end space-x-3 mt-4 pt-4 border-t">
            <button type="button" onclick="document.getElementById('addExtraIngredientModal').classList.add('hidden')" class="px-4 py-2 rounded-lg border text-gray-600 hover:bg-gray-50">Cancel</button>
            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium shadow-sm">Add Link</button>
        </div>
    </form>
</div>

<script>
function openAddProductIngredientModal(productId, productName) {
    document.getElementById('pi_product_id').value = productId;
    document.getElementById('pi_product_name_display').textContent = 'For: ' + productName;
    document.getElementById('addProductIngredientModal').classList.remove('hidden');
}

function openAddExtraIngredientModal(extraId, extraName) {
    document.getElementById('ei_extra_id').value = extraId;
    document.getElementById('ei_extra_name_display').textContent = 'For: ' + extraName;
    document.getElementById('addExtraIngredientModal').classList.remove('hidden');
}

function closeAlert(){
    document.getElementById('alertBox')?.remove();
}

// Auto close after 4 seconds
setTimeout(()=>closeAlert(),4000);
</script>

</body>
</html>
