<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
$currentPage = 'transactions';
require_once '../config/db.php';

// Fetch categories
$catResult = mysqli_query($conn, "SELECT * FROM categories WHERE LOWER(name) != 'ingredient' ORDER BY name ASC");
$categories = [];
while ($row = mysqli_fetch_assoc($catResult)) {
    $categories[] = $row;
}

// Fetch products (excluding Ingredient category) with computed stock from ingredients
$prodResult = mysqli_query($conn, "
    SELECT p.id, p.name, p.price, p.category_id, c.name AS category,
        COALESCE(
            (SELECT MIN(FLOOR(ing.stock / pi.quantity))
             FROM product_ingredients pi
             JOIN products ing ON pi.ingredient_id = ing.id
             WHERE pi.product_id = p.id),
            p.stock
        ) AS stock
    FROM products p
    JOIN categories c ON p.category_id = c.id
    WHERE LOWER(c.name) != 'ingredient'
    ORDER BY p.name ASC
");
$products = [];
while ($row = mysqli_fetch_assoc($prodResult)) {
    $products[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Transactions | Good Vibes Cafe</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
    .cart-scroll::-webkit-scrollbar { width: 4px; }
    .cart-scroll::-webkit-scrollbar-thumb { background: #d4a574; border-radius: 4px; }
    .product-card { transition: all 0.2s ease; }
    .product-card:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(0,0,0,0.1); }
    .product-card:active { transform: scale(0.97); }
    .category-tab.active { background: #d97706; color: white; }
    .cart-item { animation: slideIn 0.2s ease; }
    @keyframes slideIn { from { opacity: 0; transform: translateX(20px); } to { opacity: 1; transform: translateX(0); } }
    .checkout-btn:disabled { opacity: 0.5; cursor: not-allowed; }
</style>
</head>
<body class="flex bg-[#f5f0e8] min-h-screen">

<?php include '../includes/sidebar.php'; ?>

<div class="flex-1 flex overflow-hidden">

    <!-- LEFT: Product Grid -->
    <div class="flex-1 p-6 overflow-y-auto">
        <div class="mb-6">
            <h1 class="text-2xl font-bold text-gray-900">Transactions</h1>
            <p class="text-gray-500">Select products to add to the cart</p>
        </div>

        <!-- Search -->
        <div class="mb-4">
            <input type="text" id="searchInput" placeholder="Search products..."
                   class="w-full px-4 py-3 bg-white border border-[#e8e0d4] rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-500"
                   oninput="filterProducts()">
        </div>

        <!-- Category Tabs -->
        <div class="flex gap-2 mb-6 flex-wrap">
            <button onclick="setCategory('all')" class="category-tab active px-4 py-2 rounded-full text-sm font-medium border border-[#e8e0d4] transition-all" data-cat="all">All</button>
            <?php foreach($categories as $cat): ?>
            <button onclick="setCategory(<?= $cat['id'] ?>)" class="category-tab px-4 py-2 rounded-full text-sm font-medium border border-[#e8e0d4] bg-white text-gray-600 hover:bg-amber-50 transition-all" data-cat="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></button>
            <?php endforeach; ?>
        </div>

        <!-- Products Grid -->
        <div id="productGrid" class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            <?php foreach($products as $p): ?>
            <div class="product-card bg-white rounded-2xl border border-[#e8e0d4] p-4 cursor-pointer flex flex-col justify-between <?= $p['stock'] <= 0 ? 'opacity-50 pointer-events-none' : '' ?>"
                 data-id="<?= $p['id'] ?>"
                 data-name="<?= htmlspecialchars($p['name']) ?>"
                 data-price="<?= $p['price'] ?>"
                 data-stock="<?= $p['stock'] ?>"
                 data-category="<?= $p['category_id'] ?>"
                 onclick="addToCart(this)">

                <div class="mb-3">
                    <div class="w-full h-20 bg-gradient-to-br from-amber-100 to-orange-50 rounded-xl flex items-center justify-center mb-3">
                        <span class="text-3xl">☕</span>
                    </div>
                    <h3 class="font-semibold text-gray-900 text-sm leading-tight"><?= htmlspecialchars($p['name']) ?></h3>
                    <p class="text-xs text-gray-400 mt-1"><?= htmlspecialchars($p['category']) ?></p>
                </div>
                <div class="flex items-center justify-between">
                    <span class="text-amber-700 font-bold">₱<?= number_format($p['price'],2) ?></span>
                    <span class="text-xs px-2 py-1 rounded-full <?= $p['stock'] <= 5 ? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-600' ?>">
                        <?= $p['stock'] ?> left
                    </span>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- RIGHT: Cart Sidebar -->
    <div class="w-96 bg-white border-l border-[#e8e0d4] flex flex-col">

        <!-- Cart Header -->
        <div class="p-5 border-b border-[#e8e0d4]">
            <div class="flex items-center justify-between">
                <h2 class="text-lg font-bold text-gray-900">Current Order</h2>
                <span id="cartCount" class="bg-amber-100 text-amber-700 text-xs font-bold px-2 py-1 rounded-full">0</span>
            </div>
        </div>

        <!-- Cart Items -->
        <div id="cartItems" class="flex-1 overflow-y-auto cart-scroll p-4 space-y-3">
            <div id="emptyCart" class="flex flex-col items-center justify-center h-full text-gray-400">
                <span class="text-4xl mb-2">🛒</span>
                <p class="text-sm">Cart is empty</p>
                <p class="text-xs">Tap a product to add</p>
            </div>
        </div>

        <!-- Cart Footer -->
        <div class="border-t border-[#e8e0d4] p-5 space-y-4">
            <div class="space-y-2">
                <div class="flex justify-between text-sm text-gray-500">
                    <span>Items</span>
                    <span id="totalItems">0</span>
                </div>
                <div class="flex justify-between text-xl font-bold text-gray-900">
                    <span>Total</span>
                    <span id="totalPrice">₱0.00</span>
                </div>
            </div>
            <button id="checkoutBtn" onclick="checkout()" disabled
                    class="checkout-btn w-full py-3 bg-amber-600 hover:bg-amber-700 text-white font-semibold rounded-xl transition-colors">
                Checkout
            </button>
            <button onclick="clearCart()"
                    class="w-full py-2 text-gray-400 hover:text-red-500 text-sm font-medium transition-colors">
                Clear Cart
            </button>
        </div>
    </div>

</div>

<!-- Checkout Success Modal -->
<div id="successModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white rounded-2xl p-8 max-w-sm text-center">
        <div class="text-5xl mb-4">✅</div>
        <h2 class="text-xl font-bold text-gray-900 mb-2">Order Complete!</h2>
        <p class="text-gray-500 mb-6">The order has been processed and stock has been updated.</p>
        <button onclick="closeSuccessModal()" class="px-6 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-medium">New Order</button>
    </div>
</div>

<script>
let cart = [];
let selectedCategory = 'all';

// Available built-in modifiers, targeted by category ID
// 1=Coffee, 2=Chips, 3=Beverage, 4=Meal
const AVAILABLE_MODIFIERS = [
    { id: 'extra_shot', label: 'Extra Shot', price: 20.00, categories: [1] },
    { id: 'upsize', label: 'Upsize', price: 15.00, categories: [1, 3] },
    { id: 'extra_rice', label: 'Extra Rice', price: 25.00, categories: [4] },
    { id: 'extra_sauce', label: 'Extra Sauce', price: 15.00, categories: [2, 4] }
];

function setCategory(catId) {
    selectedCategory = catId;
    document.querySelectorAll('.category-tab').forEach(btn => {
        btn.classList.remove('active');
        btn.classList.remove('bg-white', 'text-gray-600');
    });
    const activeBtn = document.querySelector(`.category-tab[data-cat="${catId}"]`);
    activeBtn.classList.add('active');
    filterProducts();
}

function filterProducts() {
    const search = document.getElementById('searchInput').value.toLowerCase();
    document.querySelectorAll('.product-card').forEach(card => {
        const name = card.dataset.name.toLowerCase();
        const cat = card.dataset.category;
        const matchSearch = name.includes(search);
        const matchCat = selectedCategory === 'all' || cat == selectedCategory;
        card.style.display = (matchSearch && matchCat) ? '' : 'none';
    });
}

// Generate unique ID for cart items (so same product with different modifiers can exist)
function generateCartId() {
    return Date.now() + Math.floor(Math.random() * 1000);
}

function addToCart(el) {
    const id = parseInt(el.dataset.id);
    const name = el.dataset.name;
    const price = parseFloat(el.dataset.price);
    const stock = parseInt(el.dataset.stock);
    const categoryId = parseInt(el.dataset.category);

    // Always create a new entry so they can be customized independently
    cart.push({ 
        cartId: generateCartId(), 
        productId: id, 
        categoryId: categoryId,
        name: name, 
        basePrice: price, 
        stock: stock, 
        qty: 1, 
        notes: '',
        modifiers: []
    });
    
    renderCart();
}

function updateQty(cartId, delta) {
    const item = cart.find(i => i.cartId === cartId);
    if (!item) return;
    
    // Check total qty of this product across all cart items (since they are split)
    const productTotalQty = cart.filter(i => i.productId === item.productId).reduce((sum, i) => sum + i.qty, 0);
    
    if (delta > 0 && productTotalQty >= item.stock) {
        alert('Not enough stock available!');
        return;
    }

    item.qty += delta;
    if (item.qty <= 0) {
        cart = cart.filter(i => i.cartId !== cartId);
    }
    renderCart();
}

function removeItem(cartId) {
    cart = cart.filter(i => i.cartId !== cartId);
    renderCart();
}

function updateNotes(cartId, notes) {
    const item = cart.find(i => i.cartId === cartId);
    if (item) item.notes = notes;
}

function toggleModifier(cartId, modId) {
    const item = cart.find(i => i.cartId === cartId);
    if (!item) return;
    
    if (item.modifiers.includes(modId)) {
        item.modifiers = item.modifiers.filter(m => m !== modId);
    } else {
        item.modifiers.push(modId);
    }
    renderCart();
}

// Helper to calculate unit price including modifiers
function getItemUnitPrice(item) {
    let price = item.basePrice;
    item.modifiers.forEach(modId => {
        const mod = AVAILABLE_MODIFIERS.find(m => m.id === modId);
        if (mod) price += mod.price;
    });
    return price;
}

function clearCart() {
    if (cart.length === 0) return;
    if (confirm('Clear all items from the cart?')) {
        cart = [];
        renderCart();
    }
}

function renderCart() {
    const container = document.getElementById('cartItems');
    const empty = document.getElementById('emptyCart');

    if (cart.length === 0) {
        container.innerHTML = '';
        container.appendChild(createEmptyState());
        document.getElementById('cartCount').textContent = '0';
        document.getElementById('totalItems').textContent = '0';
        document.getElementById('totalPrice').textContent = '₱0.00';
        document.getElementById('checkoutBtn').disabled = true;
        return;
    }

    document.getElementById('checkoutBtn').disabled = false;
    let html = '';
    let totalItems = 0;
    let totalPrice = 0;

    cart.forEach(item => {
        const unitPrice = getItemUnitPrice(item);
        const lineTotal = unitPrice * item.qty;
        totalItems += item.qty;
        totalPrice += lineTotal;

        // Render modifier buttons specific to this item's category
        let modifierHtml = '';
        const applicableModifiers = AVAILABLE_MODIFIERS.filter(m => m.categories.includes(item.categoryId));
        
        if (applicableModifiers.length > 0) {
            modifierHtml += '<div class="flex flex-wrap gap-1 mt-2">';
            applicableModifiers.forEach(mod => {
                const isActive = item.modifiers.includes(mod.id);
                const priceLabel = mod.price > 0 ? ` (+₱${mod.price})` : '';
                const activeClasses = isActive ? 'bg-amber-600 text-white border-amber-600' : 'bg-white text-gray-500 border-[#e8e0d4] hover:border-amber-400';
                modifierHtml += `
                    <button onclick="toggleModifier(${item.cartId}, '${mod.id}')" 
                            class="text-[10px] px-2 py-1 rounded-md border transition-colors ${activeClasses}">
                        ${mod.label}${priceLabel}
                    </button>
                `;
            });
            modifierHtml += '</div>';
        }

        html += `
        <div class="cart-item bg-[#faf7f2] rounded-xl p-3 border border-[#e8e0d4]">
            <div class="flex justify-between items-start mb-2">
                <div class="flex-1">
                    <h4 class="font-semibold text-sm text-gray-900">${item.name}</h4>
                    <p class="text-xs text-gray-400">₱${unitPrice.toFixed(2)} each</p>
                </div>
                <button onclick="removeItem(${item.cartId})" class="text-gray-300 hover:text-red-500 transition-colors ml-2">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                </button>
            </div>
            <div class="flex items-center justify-between mb-2">
                <div class="flex items-center gap-2">
                    <button onclick="updateQty(${item.cartId}, -1)" class="w-7 h-7 rounded-lg bg-white border border-[#e8e0d4] flex items-center justify-center text-gray-500 hover:bg-red-50 hover:text-red-500 transition-colors font-bold text-sm">−</button>
                    <span class="font-bold text-sm w-6 text-center">${item.qty}</span>
                    <button onclick="updateQty(${item.cartId}, 1)" class="w-7 h-7 rounded-lg bg-white border border-[#e8e0d4] flex items-center justify-center text-gray-500 hover:bg-green-50 hover:text-green-500 transition-colors font-bold text-sm">+</button>
                </div>
                <span class="font-bold text-amber-700 text-sm">₱${lineTotal.toFixed(2)}</span>
            </div>
            
            <!-- Quick Modifiers -->
            ${modifierHtml}

            <!-- Custom Customization Notes -->
            <div class="mt-2">
                <textarea oninput="updateNotes(${item.cartId}, this.value)"
                    placeholder="Custom notes (e.g. less sweet...)"
                    class="w-full text-xs border border-[#e8e0d4] rounded-lg p-2 bg-white resize-none focus:outline-none focus:ring-1 focus:ring-amber-400"
                    rows="1">${item.notes}</textarea>
            </div>
        </div>`;
    });

    container.innerHTML = html;
    document.getElementById('cartCount').textContent = cart.length;
    document.getElementById('totalItems').textContent = totalItems;
    document.getElementById('totalPrice').textContent = '₱' + totalPrice.toFixed(2);
}

function createEmptyState() {
    const div = document.createElement('div');
    div.id = 'emptyCart';
    div.className = 'flex flex-col items-center justify-center h-full text-gray-400';
    div.innerHTML = '<span class="text-4xl mb-2">🛒</span><p class="text-sm">Cart is empty</p><p class="text-xs">Tap a product to add</p>';
    return div;
}

function checkout() {
    if (cart.length === 0) return;

    const btn = document.getElementById('checkoutBtn');
    btn.disabled = true;
    btn.textContent = 'Processing...';

    // Group same products before sending, but format notes properly
    const itemsPayload = [];
    
    // Process items combining modifiers into the notes string
    cart.forEach(item => {
        const unitPrice = getItemUnitPrice(item);
        
        let modifierStrings = [];
        item.modifiers.forEach(modId => {
            const mod = AVAILABLE_MODIFIERS.find(m => m.id === modId);
            if (mod) modifierStrings.push(`[${mod.label}]`);
        });
        
        // Combine built-in modifiers with manual notes
        let finalNotes = modifierStrings.join(' ');
        if (item.notes.trim()) {
            finalNotes += (finalNotes ? ' - ' : '') + item.notes.trim();
        }

        // We push each cart item individually to the backend so the distinct notes and unit prices are logged per line
        itemsPayload.push({
            product_id: item.productId,
            product_name: item.name,
            quantity: item.qty,
            unit_price: unitPrice,
            notes: finalNotes
        });
    });

    fetch('../actions/checkout.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items: itemsPayload })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            cart = [];
            renderCart();
            document.getElementById('successModal').classList.remove('hidden');
            // Update stock on product cards
            if (data.updated_stock) {
                // Stock response now might contain duplicates since we sent split items, but the backend reduces total stock correctly.
                // We'll just apply the last reported stock for each ID.
                data.updated_stock.forEach(s => {
                    const card = document.querySelector(`.product-card[data-id="${s.id}"]`);
                    if (card) {
                        card.dataset.stock = s.stock;
                        const stockLabel = card.querySelector('span:last-child');
                        if (stockLabel) stockLabel.textContent = s.stock + ' left';
                        if (s.stock <= 0) {
                            card.classList.add('opacity-50', 'pointer-events-none');
                        }
                    }
                });
            }
        } else {
            alert(data.error || 'Checkout failed');
        }
        btn.disabled = false;
        btn.textContent = 'Checkout';
    })
    .catch(() => {
        alert('Network error. Please try again.');
        btn.disabled = false;
        btn.textContent = 'Checkout';
    });
}

function closeSuccessModal() {
    document.getElementById('successModal').classList.add('hidden');
}
</script>

</body>
</html>
