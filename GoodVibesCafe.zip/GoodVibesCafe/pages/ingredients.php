<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
$currentPage = 'ingredients';
require_once '../config/db.php';

$isOwner = strtolower($_SESSION['user']['role'] ?? 'staff') === 'owner';

// Fetch all ingredients with their stock
$ingredientsQuery = "
    SELECT p.id, p.name, p.stock
    FROM products p
    JOIN categories c ON p.category_id = c.id
    WHERE LOWER(c.name) = 'ingredient'
    ORDER BY p.name ASC
";
$ingredients = mysqli_query($conn, $ingredientsQuery);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Ingredients | Good Vibes Cafe</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="flex bg-[#f5f0e8] min-h-screen">

<?php include '../includes/sidebar.php'; ?>

<div class="flex-1 p-6">

<header class="flex items-center justify-between mb-6">
    <div>
        <h1 class="text-2xl font-bold text-gray-900">Ingredients</h1>
        <p class="text-gray-500">View and manage raw ingredient stock levels</p>
    </div>
    <?php if ($isOwner): ?>
    <button onclick="document.getElementById('addModal').classList.remove('hidden')"
            class="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg">
        + Add Ingredient
    </button>
    <?php endif; ?>
</header>

<!-- ALERT BOX -->
<?php if (isset($_GET['error']) || isset($_GET['success'])): ?>
<div id="alertBox" class="mb-4 p-3 rounded-lg border flex items-center justify-between
    <?php
        if (isset($_GET['error'])) echo 'bg-red-100 border-red-300 text-red-700';
        elseif (isset($_GET['success'])) echo 'bg-green-100 border-green-300 text-green-700';
    ?>">
    <span>
        <?php
            if (isset($_GET['error']) && $_GET['error'] === 'duplicate') echo '❌ Ingredient name already exists.';
            elseif (isset($_GET['success']) && $_GET['success'] === 'added') echo '✅ Ingredient added successfully.';
            elseif (isset($_GET['success']) && $_GET['success'] === 'updated') echo '✏ Ingredient updated successfully.';
            elseif (isset($_GET['success']) && $_GET['success'] === 'deleted') echo '🗑 Ingredient deleted successfully.';
        ?>
    </span>
    <button onclick="closeAlert()" class="ml-4 text-xl leading-none font-bold hover:opacity-70">&times;</button>
</div>
<?php endif; ?>

<!-- Ingredients Table -->
<div class="overflow-x-auto">
    <table class="min-w-full bg-white rounded-xl border border-[#e8e0d4]">
        <thead class="bg-[#f5f0e8]">
            <tr>
                <th class="px-4 py-3 border-b text-left">ID</th>
                <th class="px-4 py-3 border-b text-left">Ingredient Name</th>
                <th class="px-4 py-3 border-b text-center">Stock</th>
                <th class="px-4 py-3 border-b text-center">Status</th>
                <?php if ($isOwner): ?>
                <th class="px-4 py-3 border-b text-center">Actions</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php while ($ing = mysqli_fetch_assoc($ingredients)): ?>
            <tr class="border-b hover:bg-gray-50">
                <td class="px-4 py-3 text-gray-500"><?= $ing['id'] ?></td>
                <td class="px-4 py-3 font-medium"><?= htmlspecialchars($ing['name']) ?></td>
                <td class="px-4 py-3 text-center font-bold"><?= $ing['stock'] ?></td>
                <td class="px-4 py-3 text-center">
                    <?php if ($ing['stock'] <= 0): ?>
                        <span class="bg-red-100 text-red-700 text-xs font-semibold px-2 py-1 rounded-full">Out of Stock</span>
                    <?php elseif ($ing['stock'] <= 10): ?>
                        <span class="bg-amber-100 text-amber-700 text-xs font-semibold px-2 py-1 rounded-full">Low Stock</span>
                    <?php else: ?>
                        <span class="bg-green-100 text-green-700 text-xs font-semibold px-2 py-1 rounded-full">In Stock</span>
                    <?php endif; ?>
                </td>
                <?php if ($isOwner): ?>
                <td class="px-4 py-3 text-center space-x-2">
                    <button onclick="openEditModal(<?= $ing['id'] ?>,'<?= htmlspecialchars(addslashes($ing['name'])) ?>',<?= $ing['stock'] ?>)"
                            class="bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded text-sm">Edit</button>
                    <form action="../actions/ingredient_crud.php" method="POST" class="inline">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?= $ing['id'] ?>">
                        <button type="submit" class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded text-sm"
                                onclick="return confirm('Delete this ingredient?')">Delete</button>
                    </form>
                </td>
                <?php endif; ?>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
</div>

<?php if ($isOwner): ?>
<!-- Add Modal -->
<div id="addModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
<form action="../actions/ingredient_crud.php" method="POST" class="bg-white p-6 rounded-xl w-96">
<h2 class="text-lg font-bold mb-4">Add Ingredient</h2>
<input type="hidden" name="action" value="create">

<div class="mb-3">
<label class="block text-sm font-medium mb-1">Name</label>
<input type="text" name="name" required class="w-full border rounded-lg px-3 py-2">
</div>

<div class="mb-4">
<label class="block text-sm font-medium mb-1">Initial Stock</label>
<input type="number" name="stock" value="0" min="0" required class="w-full border rounded-lg px-3 py-2">
</div>

<div class="flex justify-end space-x-2 mt-4">
<button type="button" onclick="document.getElementById('addModal').classList.add('hidden')" class="px-4 py-2 rounded-lg border">Cancel</button>
<button type="submit" class="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg">Add</button>
</div>
</form>
</div>

<!-- Edit Modal -->
<div id="editModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
<form action="../actions/ingredient_crud.php" method="POST" class="bg-white p-6 rounded-xl w-96">
<h2 class="text-lg font-bold mb-4">Edit Ingredient</h2>
<input type="hidden" name="action" value="update">
<input type="hidden" name="id" id="edit_id">

<div class="mb-3">
<label class="block text-sm font-medium mb-1">Name</label>
<input type="text" name="name" id="edit_name" required class="w-full border rounded-lg px-3 py-2">
</div>

<div class="mb-4">
<label class="block text-sm font-medium mb-1">Stock</label>
<input type="number" name="stock" id="edit_stock" min="0" required class="w-full border rounded-lg px-3 py-2">
</div>

<div class="flex justify-end space-x-2 mt-4">
<button type="button" onclick="document.getElementById('editModal').classList.add('hidden')" class="px-4 py-2 rounded-lg border">Cancel</button>
<button type="submit" class="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg">Update</button>
</div>
</form>
</div>
<?php endif; ?>

<script>
function openEditModal(id, name, stock) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_name').value = name;
    document.getElementById('edit_stock').value = stock;
    document.getElementById('editModal').classList.remove('hidden');
}

function closeAlert() {
    document.getElementById('alertBox')?.remove();
}

setTimeout(() => closeAlert(), 4000);
</script>

</body>
</html>
