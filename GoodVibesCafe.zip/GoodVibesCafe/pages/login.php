<?php
session_start();
$error = $_SESSION['login_error'] ?? '';
unset($_SESSION['login_error']);

// Dynamic base path: /GoodVibesCafe on XAMPP, empty on InfinityFree
$basePath = rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'])), '/\\');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Good Vibes Cafe | Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-[#f5f0e8] flex items-center justify-center p-4">

    <div class="w-full max-w-md bg-[#fffdf9] rounded-3xl shadow-xl border border-[#e8e0d4] overflow-hidden">

        <div class="p-8 sm:p-10">

            <div class="text-center mb-10">
                <!-- Logo -->
                <img src="<?= $basePath ?>/assets/images/pasted-image.jpg" alt="Good Vibes Cafe Logo" class="w-28 h-28 rounded-full mx-auto mb-6 shadow-lg border-4">

                <h1 class="text-2xl font-bold text-gray-900 mb-1">
                    Mang Ambo's Good Vibes Cafe
                </h1>
                <p class="text-amber-700 text-sm font-medium">At The Deck</p>
                <p class="text-gray-500 text-xs mt-2">
                    Inventory Management System
                </p>
            </div>

            <!-- Display error if login failed -->
            <?php if($error): ?>
                <div class="bg-red-100 text-red-700 px-4 py-2 rounded-lg mb-4">
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <!-- Login Form -->
            <form action="../actions/login.php" method="POST" class="space-y-5">

                <div>
                    <label class="text-xs font-semibold text-gray-500 uppercase ml-1">
                        Email Address
                    </label>
                    <input type="email" name="email" placeholder="admin@goodvibes.com" required
                           class="w-full px-4 py-3 bg-[#faf7f2] border border-[#e8e0d4] rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500">
                </div>

                <div>
                    <label class="text-xs font-semibold text-gray-500 uppercase ml-1">
                        Password
                    </label>
                    <input type="password" name="password" placeholder="••••••••" required
                           class="w-full px-4 py-3 bg-[#faf7f2] border border-[#e8e0d4] rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500">
                </div>

                <button type="submit"
                        class="w-full bg-amber-600 hover:bg-amber-700 text-white py-3 rounded-xl font-semibold">
                    Sign In
                </button>

            </form>

        </div>

        <div class="px-8 py-4 bg-[#f5f0e8] border-t text-center">
            <p class="text-xs text-gray-400">
                &copy; 2026 Good Vibes Cafe — Antipolo City, Philippines.
            </p>
        </div>

    </div>

</body>
</html>