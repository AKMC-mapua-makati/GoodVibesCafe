<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

// Staff redirect - dashboard only for staff besides POS
$userRole = strtolower($_SESSION['user']['role'] ?? 'staff');

$currentPage = 'dashboard';
require_once '../config/db.php';

// =====================
// Dashboard Metrics
// =====================

// Total Products (menu items only, exclude ingredients)
$totalProducts = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) AS total FROM products p JOIN categories c ON p.category_id = c.id WHERE LOWER(c.name) != 'ingredient'")
)['total'];

// Total Categories
$totalCategories = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) AS total FROM categories")
)['total'];

// Total Orders (from order_logs)
$totalOrders = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) AS total FROM order_logs")
)['total'];

// Total Sales (from order_logs)
$totalSales = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COALESCE(SUM(total_price),0) AS total FROM order_logs")
)['total'] ?? 0;

// Total Ingredient Units in stock
$totalIngredientUnits = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COALESCE(SUM(p.stock),0) AS total FROM products p JOIN categories c ON p.category_id = c.id WHERE LOWER(c.name) = 'ingredient'")
)['total'] ?? 0;

// Low Stock: compute stock from ingredients for menu products
$lowStockResult = mysqli_query($conn, "
    SELECT p.name,
        COALESCE(
            (SELECT MIN(FLOOR(ing.stock / pi.quantity))
             FROM product_ingredients pi
             JOIN products ing ON pi.ingredient_id = ing.id
             WHERE pi.product_id = p.id),
            p.stock
        ) AS stock
    FROM products p
    JOIN categories c ON p.category_id = c.id
    WHERE LOWER(c.name) != 'ingredient'
    HAVING stock <= 5
    ORDER BY stock ASC
");
$lowStockProducts = [];
while ($row = mysqli_fetch_assoc($lowStockResult)) {
    $lowStockProducts[] = $row;
}

// Recent Orders (from order_logs)
$recentOrders = mysqli_query($conn, "
    SELECT product_name, quantity, unit_price, total_price, processed_by, customization_notes, created_at
    FROM order_logs
    ORDER BY created_at DESC
    LIMIT 10
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Dashboard | Good Vibes Cafe</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="flex bg-[#f5f0e8] min-h-screen">

<?php include '../includes/sidebar.php'; ?>

<div class="flex-1 p-6 space-y-8 overflow-y-auto">

    <div>
        <h1 class="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p class="text-gray-500">Business overview and performance metrics</p>
    </div>

    <!-- Metric Cards -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div class="bg-white p-5 rounded-xl border border-[#e8e0d4]">
            <p class="text-gray-500 text-sm">Total Products</p>
            <h2 class="text-3xl font-bold"><?= $totalProducts ?></h2>
        </div>
        <div class="bg-white p-5 rounded-xl border border-[#e8e0d4]">
            <p class="text-gray-500 text-sm">Total Categories</p>
            <h2 class="text-3xl font-bold"><?= $totalCategories ?></h2>
        </div>
        <div class="bg-white p-5 rounded-xl border border-[#e8e0d4]">
            <p class="text-gray-500 text-sm">Total Orders</p>
            <h2 class="text-3xl font-bold"><?= $totalOrders ?></h2>
        </div>
        <div class="bg-white p-5 rounded-xl border border-[#e8e0d4]">
            <p class="text-gray-500 text-sm">Total Sales</p>
            <h2 class="text-3xl font-bold">₱<?= number_format($totalSales,2) ?></h2>
        </div>
    </div>

    <!-- Stock Value + Alerts -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

        <div class="bg-white p-6 rounded-xl border border-[#e8e0d4]">
            <h3 class="font-bold mb-3">Total Ingredient Units</h3>
            <p class="text-4xl font-bold text-amber-600"><?= number_format($totalIngredientUnits) ?></p>
            <p class="text-xs text-gray-400 mt-1">Raw ingredient items in stock</p>
        </div>

        <div class="bg-white p-6 rounded-xl border border-[#e8e0d4]">
            <h3 class="font-bold mb-3">Low Stock Alerts</h3>
            <div class="space-y-2">
                <?php if(empty($lowStockProducts)): ?>
                    <p class="text-green-600">All products sufficiently stocked</p>
                <?php else: ?>
                    <?php foreach($lowStockProducts as $p): ?>
                        <div class="flex justify-between bg-red-50 px-3 py-2 rounded">
                            <span><?= htmlspecialchars($p['name']) ?></span>
                            <span class="font-bold <?= $p['stock'] == 0 ? 'text-red-600' : 'text-amber-600' ?>"><?= $p['stock'] ?> left</span>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Recent Orders -->
    <div class="bg-white p-6 rounded-xl border border-[#e8e0d4]">
        <h3 class="font-bold mb-4">Recent Orders</h3>

        <table class="w-full text-left border-collapse">
            <thead>
                <tr class="border-b">
                    <th class="py-2 text-xs font-medium text-gray-500 uppercase">Product</th>
                    <th class="text-xs font-medium text-gray-500 uppercase">Qty</th>
                    <th class="text-xs font-medium text-gray-500 uppercase">Total</th>
                    <th class="text-xs font-medium text-gray-500 uppercase">By</th>
                    <th class="text-xs font-medium text-gray-500 uppercase">Notes</th>
                    <th class="text-xs font-medium text-gray-500 uppercase">Date</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($recentOrders)): ?>
                <tr class="border-b text-sm">
                    <td class="py-2 font-medium"><?= htmlspecialchars($row['product_name']) ?></td>
                    <td><?= $row['quantity'] ?></td>
                    <td class="text-amber-700 font-semibold">₱<?= number_format($row['total_price'],2) ?></td>
                    <td class="text-gray-500"><?= htmlspecialchars($row['processed_by']) ?></td>
                    <td class="text-gray-400 text-xs max-w-[150px] truncate"><?= $row['customization_notes'] ? htmlspecialchars($row['customization_notes']) : '—' ?></td>
                    <td class="text-gray-500"><?= date("M d, h:i A", strtotime($row['created_at'])) ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

</div>

</body>
</html>