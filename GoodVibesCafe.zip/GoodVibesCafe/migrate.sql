-- GoodVibesCafe Migration Script
-- Run this ONCE against the 'goodvibescafe' database
-- Back up your database before running!

-- 1. Update roles: admin -> owner
UPDATE users SET role = 'owner' WHERE LOWER(role) = 'admin';

-- 2. Drop old transaction-related tables (order matters for FK constraints)
DROP TABLE IF EXISTS transaction_logs;
DROP TABLE IF EXISTS transaction_items;
DROP TABLE IF EXISTS stock_movements;
DROP TABLE IF EXISTS transactions;

-- 3. Create order_logs table
CREATE TABLE IF NOT EXISTS order_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(255) NOT NULL,
    product_id INT DEFAULT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    customization_notes TEXT DEFAULT NULL,
    processed_by VARCHAR(255) NOT NULL,
    user_id INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Add Ingredient category if it doesn't exist
INSERT IGNORE INTO categories (name) VALUES ('Ingredient');

-- 5. Create recipe tables
CREATE TABLE IF NOT EXISTS product_ingredients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    ingredient_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (ingredient_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE KEY unique_product_ingredient (product_id, ingredient_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS extra_ingredients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    extra_id VARCHAR(50) NOT NULL,
    ingredient_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    FOREIGN KEY (ingredient_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE KEY unique_extra_ingredient (extra_id, ingredient_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
