<?php
$ch = curl_init('http://localhost/GoodVibesCafe/actions/login.php');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'email=admin@goodvibescafe.com&password=admin123');
curl_setopt($ch, CURLOPT_HEADER, true);
$res = curl_exec($ch);
preg_match('/PHPSESSID=([^;]+)/', $res, $m);
$sess = $m[1] ?? '';

$ch2 = curl_init('http://localhost/GoodVibesCafe/actions/checkout.php');
curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch2, CURLOPT_POST, true);
curl_setopt($ch2, CURLOPT_HTTPHEADER, ['Content-Type: application/json', 'Cookie: PHPSESSID='.$sess]);
$payload = json_encode(['items'=>[['product_id'=>1,'product_name'=>'Hot Americano','quantity'=>2,'unit_price'=>100,'notes'=>'[Extra Shot]']]]);
curl_setopt($ch2, CURLOPT_POSTFIELDS, $payload);

$res2 = curl_exec($ch2);
echo "Checkout Res: " . $res2 . "\n";
?>
