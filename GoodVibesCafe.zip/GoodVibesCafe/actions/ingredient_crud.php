<?php
session_start();
require_once '../config/db.php';

// Only owner can manage ingredients
if (!isset($_SESSION['user']) || strtolower($_SESSION['user']['role']) !== 'owner') {
    header("Location: ../pages/dashboard.php");
    exit();
}

// Get the Ingredient category ID
$catRes = mysqli_query($conn, "SELECT id FROM categories WHERE LOWER(name) = 'ingredient'");
$catRow = mysqli_fetch_assoc($catRes);
$ingredientCategoryId = $catRow ? (int)$catRow['id'] : 0;

$action = $_POST['action'] ?? '';

/* ========== CREATE ========== */
if ($action === 'create') {
    $name = trim($_POST['name']);
    $stock = (int)$_POST['stock'];

    $check = mysqli_prepare($conn, "SELECT id FROM products WHERE name = ?");
    mysqli_stmt_bind_param($check, "s", $name);
    mysqli_stmt_execute($check);
    mysqli_stmt_store_result($check);

    if (mysqli_stmt_num_rows($check) > 0) {
        mysqli_stmt_close($check);
        header("Location: ../pages/ingredients.php?error=duplicate");
        exit();
    }
    mysqli_stmt_close($check);

    $stmt = mysqli_prepare($conn, "INSERT INTO products (name, category_id, price, stock) VALUES (?, ?, 0, ?)");
    mysqli_stmt_bind_param($stmt, "sii", $name, $ingredientCategoryId, $stock);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("Location: ../pages/ingredients.php?success=added");
    exit();
}

/* ========== UPDATE ========== */
elseif ($action === 'update') {
    $id = (int)$_POST['id'];
    $name = trim($_POST['name']);
    $stock = (int)$_POST['stock'];

    $check = mysqli_prepare($conn, "SELECT id FROM products WHERE name = ? AND id != ?");
    mysqli_stmt_bind_param($check, "si", $name, $id);
    mysqli_stmt_execute($check);
    mysqli_stmt_store_result($check);

    if (mysqli_stmt_num_rows($check) > 0) {
        mysqli_stmt_close($check);
        header("Location: ../pages/ingredients.php?error=duplicate");
        exit();
    }
    mysqli_stmt_close($check);

    $stmt = mysqli_prepare($conn, "UPDATE products SET name=?, stock=? WHERE id=?");
    mysqli_stmt_bind_param($stmt, "sii", $name, $stock, $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("Location: ../pages/ingredients.php?success=updated");
    exit();
}

/* ========== DELETE ========== */
elseif ($action === 'delete') {
    $id = (int)$_POST['id'];

    // Check if used in recipes
    $check = mysqli_prepare($conn, "SELECT id FROM product_ingredients WHERE ingredient_id = ? LIMIT 1");
    mysqli_stmt_bind_param($check, "i", $id);
    mysqli_stmt_execute($check);
    mysqli_stmt_store_result($check);

    if (mysqli_stmt_num_rows($check) > 0) {
        mysqli_stmt_close($check);
        header("Location: ../pages/ingredients.php?error=linked");
        exit();
    }
    mysqli_stmt_close($check);

    $stmt = mysqli_prepare($conn, "DELETE FROM products WHERE id=?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("Location: ../pages/ingredients.php?success=deleted");
    exit();
}

header("Location: ../pages/ingredients.php");
exit();
?>
