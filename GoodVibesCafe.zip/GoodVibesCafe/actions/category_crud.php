<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user']) || strtolower($_SESSION['user']['role']) !== 'owner') {
    header("Location: ../pages/dashboard.php");
    exit();
}

$action = $_POST['action'] ?? '';

if ($action === 'create') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);

    // Duplicate check
    $check = mysqli_query($conn, "SELECT id FROM categories WHERE name='$name'");
    if (mysqli_num_rows($check) > 0) {
        header("Location: ../pages/categories.php?error=duplicate");
        exit();
    }

    mysqli_query($conn, "INSERT INTO categories (name) VALUES ('$name')");
    header("Location: ../pages/categories.php?success=added");
    exit();
}

if ($action === 'update') {
    $id = (int)$_POST['id'];
    $name = mysqli_real_escape_string($conn, $_POST['name']);

    // Duplicate check excluding self
    $check = mysqli_query($conn, "SELECT id FROM categories WHERE name='$name' AND id!=$id");
    if (mysqli_num_rows($check) > 0) {
        header("Location: ../pages/categories.php?error=duplicate");
        exit();
    }

    mysqli_query($conn, "UPDATE categories SET name='$name' WHERE id=$id");
    header("Location: ../pages/categories.php?success=updated");
    exit();
}

if ($action === 'delete') {
    $id = (int)$_POST['id'];

    // Check if linked to products
    $check = mysqli_query($conn, "SELECT id FROM products WHERE category_id=$id");
    if (mysqli_num_rows($check) > 0) {
        header("Location: ../pages/categories.php?error=linked");
        exit();
    }

    mysqli_query($conn, "DELETE FROM categories WHERE id=$id");
    header("Location: ../pages/categories.php?success=deleted");
    exit();
}

header("Location: ../pages/categories.php");
exit();