<?php
session_start();
require_once '../config/db.php';

// Only owner can download logs
if (!isset($_SESSION['user']) || strtolower($_SESSION['user']['role']) !== 'owner') {
    header("Location: ../pages/login.php");
    exit();
}

$start = $_GET['start'] ?? '';
$end = $_GET['end'] ?? '';
$search = $_GET['search'] ?? '';
$categoryIds = $_GET['categories'] ?? [];

$where = [];
if ($start) $where[] = "DATE(o.created_at) >= '" . mysqli_real_escape_string($conn, $start) . "'";
if ($end) $where[] = "DATE(o.created_at) <= '" . mysqli_real_escape_string($conn, $end) . "'";
if ($search) {
    $s = mysqli_real_escape_string($conn, $search);
    $where[] = "(o.product_name LIKE '%$s%' OR o.processed_by LIKE '%$s%')";
}
if (!empty($categoryIds) && is_array($categoryIds)) {
    $safeIds = array_map(function($id) use ($conn) {
        return (int) mysqli_real_escape_string($conn, $id);
    }, $categoryIds);
    $inString = implode(',', $safeIds);
    $where[] = "p.category_id IN ($inString)";
}
$whereClause = count($where) > 0 ? "WHERE " . implode(' AND ', $where) : "";

$query = "
    SELECT o.product_name, o.quantity, o.unit_price, o.total_price, o.customization_notes, o.processed_by, o.created_at 
    FROM order_logs o
    LEFT JOIN products p ON o.product_id = p.id
    $whereClause 
    ORDER BY o.created_at DESC
";
$result = mysqli_query($conn, $query);

// Check if TCPDF or FPDF is available in vendor logic. 
// Since we don't have a reliable PDF library installed via Composer in the project dir yet,
// we will generate a clean Printable HTML page that naturally acts as a PDF output via the browser's native print-to-pdf,
// or falling back to a direct CSV export if requested. Here we provide the print view which handles "PDF" generation elegantly.

$isCsv = isset($_GET['format']) && $_GET['format'] === 'csv';

if ($isCsv) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="GoodVibesCafe_Logs.csv"');
    $output = fopen('php://output', 'w');
    fputcsv($output, ['Date', 'Product', 'Quantity', 'Unit Price', 'Total', 'Notes', 'Processed By']);
    while ($row = mysqli_fetch_assoc($result)) {
        fputcsv($output, [
            $row['created_at'],
            $row['product_name'],
            $row['quantity'],
            $row['unit_price'],
            $row['total_price'],
            $row['customization_notes'],
            $row['processed_by']
        ]);
    }
    fclose($output);
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Logs Report</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; color: #333; margin: 40px; }
        .header { text-align: center; margin-bottom: 30px; }
        .header h1 { margin: 0; color: #b45309; }
        .header p { margin: 5px 0; color: #666; }
        table { w-full: 100%; border-collapse: collapse; margin-top: 20px; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px 12px; text-align: left; }
        th { background-color: #f3f4f6; color: #374151; }
        tr:nth-child(even) { background-color: #f9fafb; }
        .text-right { text-align: right; }
        .total-row td { font-weight: bold; background-color: #fef3c7; border-top: 2px solid #f59e0b; }
        @media print {
            @page { margin: 1cm; size: landscape; }
            button { display: none; }
            body { margin: 0; }
        }
        .print-btn {
            background-color: #d97706; color: white; border: none; padding: 10px 20px;
            cursor: pointer; border-radius: 5px; font-weight: bold; margin-bottom: 20px;
        }
        .print-btn:hover { background-color: #b45309; }
    </style>
</head>
<body>
    <button class="print-btn" onclick="window.print()">Print / Save as PDF</button>
    
    <div class="header">
        <h1>Good Vibes Cafe</h1>
        <p>Order Logs Report</p>
        <?php if($start && $end): ?>
            <p>Date Range: <?= htmlspecialchars($start) ?> to <?= htmlspecialchars($end) ?></p>
        <?php else: ?>
            <p>All-Time Records</p>
        <?php endif; ?>
        <p>Generated on: <?= date('Y-m-d H:i:s') ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th>Date / Time</th>
                <th>Product</th>
                <th class="text-right">Qty</th>
                <th class="text-right">Unit Price</th>
                <th class="text-right">Total</th>
                <th>Customization Notes</th>
                <th>Staff/Owner</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $grandTotal = 0;
            $itemsCount = 0;
            while ($row = mysqli_fetch_assoc($result)): 
                $grandTotal += $row['total_price'];
                $itemsCount += $row['quantity'];
            ?>
            <tr>
                <td><?= date('M d, Y g:i A', strtotime($row['created_at'])) ?></td>
                <td><strong><?= htmlspecialchars($row['product_name']) ?></strong></td>
                <td class="text-right"><?= htmlspecialchars($row['quantity']) ?></td>
                <td class="text-right">₱<?= number_format($row['unit_price'], 2) ?></td>
                <td class="text-right">₱<?= number_format($row['total_price'], 2) ?></td>
                <td><?= htmlspecialchars($row['customization_notes'] ?: '-') ?></td>
                <td><?= htmlspecialchars($row['processed_by']) ?></td>
            </tr>
            <?php endwhile; ?>
            
            <tr class="total-row">
                <td colspan="2" class="text-right">GRAND TOTAL</td>
                <td class="text-right"><?= $itemsCount ?> items</td>
                <td></td>
                <td class="text-right">₱<?= number_format($grandTotal, 2) ?></td>
                <td colspan="2"></td>
            </tr>
        </tbody>
    </table>
    
    <script>
        // Auto-open print dialog when ready
        window.onload = () => { window.print(); };
    </script>
</body>
</html>
