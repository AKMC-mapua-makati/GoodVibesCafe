<?php 
session_start();
if (!isset($_SESSION['user']) || strtolower($_SESSION['user']['role']) !== 'owner') {
    header("Location: ../pages/dashboard.php");
    exit();
}

require_once '../config/db.php';

$action = $_POST['action'] ?? '';

if ($action === 'create') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    $role = 'staff'; // Enforce staff creation only
    
    // Check email
    $check = mysqli_query($conn, "SELECT id FROM users WHERE email='$email'");
    if (mysqli_num_rows($check) > 0) {
        $_SESSION['error_message'] = "Email already exists.";
        header("Location: ../pages/users.php");
        exit();
    }

    mysqli_query($conn, "INSERT INTO users (name,email,password,role,status) VALUES ('$name','$email','$password','$role','$status')");
    header("Location: ../pages/users.php");
    exit();
}

if ($action === 'update') {
    $id = (int)$_POST['id'];
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $role = mysqli_real_escape_string($conn, $_POST['role']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

    $passwordSql = '';
    if (!empty($_POST['password'])) {
        $password = mysqli_real_escape_string($conn, $_POST['password']);
        $passwordSql = ", password='$password'";
    }

    mysqli_query($conn, "UPDATE users SET name='$name', email='$email', role='$role', status='$status' $passwordSql WHERE id=$id");
    header("Location: ../pages/users.php");
    exit();
}

if ($action === 'delete') {
    $id = (int)$_POST['id'];
    mysqli_query($conn, "DELETE FROM users WHERE id=$id");
    header("Location: ../pages/users.php");
    exit();
}
?>