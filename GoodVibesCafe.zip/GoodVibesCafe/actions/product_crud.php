<?php 
// actions/product_crud.php
session_start();
require_once '../config/db.php';

// Only owner can manage products
if (!isset($_SESSION['user']) || strtolower($_SESSION['user']['role']) !== 'owner') {
    header("Location: ../pages/dashboard.php");
    exit();
}

// Helper: check if category is 'Ingredient'
function isIngredientCategory($conn, $category_id) {
    $res = mysqli_query($conn, "SELECT name FROM categories WHERE id = $category_id");
    $row = mysqli_fetch_assoc($res);
    return $row && strtolower($row['name']) === 'ingredient';
}

// Determine action
$action = $_POST['action'] ?? '';

/* ========== CREATE PRODUCT ========== */
if ($action === 'create') {

    $name = trim($_POST['name']);
    $category_id = (int)$_POST['category_id'];
    $price = (float)$_POST['price'];
    
    // Only ingredient items have their own stock; menu products get 0
    $stock = isIngredientCategory($conn, $category_id) ? (int)($_POST['stock'] ?? 0) : 0;

    // Check duplicate name
    $check = mysqli_prepare($conn, "SELECT id FROM products WHERE name = ?");
    mysqli_stmt_bind_param($check, "s", $name);
    mysqli_stmt_execute($check);
    mysqli_stmt_store_result($check);

    if (mysqli_stmt_num_rows($check) > 0) {
        mysqli_stmt_close($check);
        header("Location: ../pages/products.php?error=duplicate");
        exit();
    }
    mysqli_stmt_close($check);

    // Insert product
    $stmt = mysqli_prepare($conn,
        "INSERT INTO products (name, category_id, price, stock) 
         VALUES (?, ?, ?, ?)"
    );
    mysqli_stmt_bind_param($stmt, "sidi", 
        $name, $category_id, $price, $stock
    );
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("Location: ../pages/products.php?success=added");
    exit();
}

/* ========== UPDATE PRODUCT ========== */
elseif ($action === 'update') {

    $id = (int)$_POST['id'];
    $name = trim($_POST['name']);
    $category_id = (int)$_POST['category_id'];
    $price = (float)$_POST['price'];
    
    // Only ingredient items can update stock; menu products keep 0
    $isIngredient = isIngredientCategory($conn, $category_id);
    $stock = $isIngredient ? (int)($_POST['stock'] ?? 0) : 0;

    // Duplicate check (exclude current)
    $check = mysqli_prepare($conn,
        "SELECT id FROM products WHERE name = ? AND id != ?"
    );
    mysqli_stmt_bind_param($check, "si", $name, $id);
    mysqli_stmt_execute($check);
    mysqli_stmt_store_result($check);

    if (mysqli_stmt_num_rows($check) > 0) {
        mysqli_stmt_close($check);
        header("Location: ../pages/products.php?error=duplicate");
        exit();
    }
    mysqli_stmt_close($check);

    // Update
    $stmt = mysqli_prepare($conn,
        "UPDATE products 
         SET name=?, category_id=?, price=?, stock=? 
         WHERE id=?"
    );
    mysqli_stmt_bind_param($stmt, "sidii",
        $name, $category_id, $price, $stock, $id
    );
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("Location: ../pages/products.php?success=updated");
    exit();
}

/* ========== DELETE PRODUCT ========== */
elseif ($action === 'delete') {

    $id = (int)$_POST['id'];

    // Prevent deleting product used in order logs
    $check = mysqli_prepare($conn,
        "SELECT id FROM order_logs WHERE product_id = ? LIMIT 1"
    );
    mysqli_stmt_bind_param($check, "i", $id);
    mysqli_stmt_execute($check);
    mysqli_stmt_store_result($check);

    if (mysqli_stmt_num_rows($check) > 0) {
        mysqli_stmt_close($check);
        header("Location: ../pages/products.php?error=linked");
        exit();
    }
    mysqli_stmt_close($check);

    $stmt = mysqli_prepare($conn, "DELETE FROM products WHERE id=?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("Location: ../pages/products.php?success=deleted");
    exit();
}

header("Location: ../pages/products.php");
exit();
?>