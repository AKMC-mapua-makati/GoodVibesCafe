<?php
session_start();
require_once "../config/db.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password_input = $_POST['password'];

    $query = "SELECT * FROM users WHERE email='$email' AND password='$password_input' AND status='Active'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) === 1) {
        $user = mysqli_fetch_assoc($result);

        $_SESSION['user'] = [
            'id' => $user['id'],
            'name' => $user['name'],
            'email' => $user['email'],
            'role' => $user['role']
        ];

        header("Location: ../pages/dashboard.php");
        exit();
    } else {
        $_SESSION['login_error'] = "Invalid email, password, or account inactive.";
        header("Location: ../pages/login.php");
        exit();
    }
}
?>