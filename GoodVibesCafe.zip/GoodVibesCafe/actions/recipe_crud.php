<?php
session_start();
require_once '../config/db.php';

// Only owner can manage recipes
if (!isset($_SESSION['user']) || strtolower($_SESSION['user']['role']) !== 'owner') {
    header("Location: ../pages/dashboard.php");
    exit();
}

$action = $_POST['action'] ?? '';

/* ========== ADD PRODUCT INGREDIENT ========== */
if ($action === 'add_product_ingredient') {
    $product_id = (int)$_POST['product_id'];
    $ingredient_id = (int)$_POST['ingredient_id'];
    $quantity = (int)$_POST['quantity'];
    
    // Check if link exists
    $check = mysqli_prepare($conn, "SELECT id FROM product_ingredients WHERE product_id = ? AND ingredient_id = ?");
    mysqli_stmt_bind_param($check, "ii", $product_id, $ingredient_id);
    mysqli_stmt_execute($check);
    mysqli_stmt_store_result($check);
    
    if (mysqli_stmt_num_rows($check) > 0) {
        mysqli_stmt_close($check);
        header("Location: ../pages/recipes.php?error=product_exists");
        exit();
    }
    mysqli_stmt_close($check);

    $stmt = mysqli_prepare($conn, "INSERT INTO product_ingredients (product_id, ingredient_id, quantity) VALUES (?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "iii", $product_id, $ingredient_id, $quantity);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    
    header("Location: ../pages/recipes.php?success=product_added");
    exit();
}

/* ========== REMOVE PRODUCT INGREDIENT ========== */
elseif ($action === 'remove_product_ingredient') {
    $id = (int)$_POST['id'];
    $stmt = mysqli_prepare($conn, "DELETE FROM product_ingredients WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    
    header("Location: ../pages/recipes.php?success=product_removed");
    exit();
}

/* ========== ADD EXTRA INGREDIENT ========== */
elseif ($action === 'add_extra_ingredient') {
    $extra_id = trim($_POST['extra_id']);
    $ingredient_id = (int)$_POST['ingredient_id'];
    $quantity = (int)$_POST['quantity'];
    
    // Check if link exists
    $check = mysqli_prepare($conn, "SELECT id FROM extra_ingredients WHERE extra_id = ? AND ingredient_id = ?");
    mysqli_stmt_bind_param($check, "si", $extra_id, $ingredient_id);
    mysqli_stmt_execute($check);
    mysqli_stmt_store_result($check);
    
    if (mysqli_stmt_num_rows($check) > 0) {
        mysqli_stmt_close($check);
        header("Location: ../pages/recipes.php?error=extra_exists");
        exit();
    }
    mysqli_stmt_close($check);

    $stmt = mysqli_prepare($conn, "INSERT INTO extra_ingredients (extra_id, ingredient_id, quantity) VALUES (?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "sii", $extra_id, $ingredient_id, $quantity);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    
    header("Location: ../pages/recipes.php?success=extra_added");
    exit();
}

/* ========== REMOVE EXTRA INGREDIENT ========== */
elseif ($action === 'remove_extra_ingredient') {
    $id = (int)$_POST['id'];
    $stmt = mysqli_prepare($conn, "DELETE FROM extra_ingredients WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    
    header("Location: ../pages/recipes.php?success=extra_removed");
    exit();
}

header("Location: ../pages/recipes.php");
exit();
?>
