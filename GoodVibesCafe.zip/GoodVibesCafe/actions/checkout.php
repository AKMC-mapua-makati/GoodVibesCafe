<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user'])) {
    echo json_encode(['success' => false, 'error' => 'Not authenticated']);
    exit();
}

require_once '../config/db.php';

// Read JSON body
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['items']) || !is_array($input['items']) || count($input['items']) === 0) {
    echo json_encode(['success' => false, 'error' => 'No items in cart']);
    exit();
}

$userId = (int)$_SESSION['user']['id'];
$userName = $_SESSION['user']['name'];
$items = $input['items'];

// Begin transaction for atomicity
mysqli_begin_transaction($conn);

try {
    $ingredientDeductions = []; // ingredient_id => total quantity to deduct

    // 1. Walk through each cart item, gather all required ingredient deductions
    foreach ($items as $item) {
        $productId = (int)$item['product_id'];
        $quantity = (int)$item['quantity'];
        $unitPrice = (float)$item['unit_price'];
        $productName = $item['product_name'] ?? '';
        $notes = $item['notes'] ?? '';

        if ($quantity <= 0) {
            throw new Exception("Invalid quantity for $productName");
        }

        // Verify product exists (lock row)
        $res = mysqli_query($conn, "SELECT stock, name, price FROM products WHERE id=$productId FOR UPDATE");
        $product = mysqli_fetch_assoc($res);

        if (!$product) {
            throw new Exception("Product not found: $productName");
        }

        // Gather base product ingredient requirements
        $ingRes = mysqli_query($conn, "SELECT ingredient_id, quantity FROM product_ingredients WHERE product_id = $productId");
        $hasIngredients = mysqli_num_rows($ingRes) > 0;

        if ($hasIngredients) {
            // Ingredient-based product: deduct from ingredients
            while ($ing = mysqli_fetch_assoc($ingRes)) {
                $ingId = (int)$ing['ingredient_id'];
                $reqQty = (int)$ing['quantity'] * $quantity;
                if (!isset($ingredientDeductions[$ingId])) $ingredientDeductions[$ingId] = 0;
                $ingredientDeductions[$ingId] += $reqQty;
            }
        }
        // Products without recipes have no stock to deduct (stock is 0, nothing to subtract)

        // Gather extra/modifier ingredient requirements from notes
        // Modifiers are encoded as [Label] in notes (e.g., "[Extra Shot]", "[Extra Rice]")
        preg_match_all('/\[(.*?)\]/', $notes, $matches);
        if (!empty($matches[1])) {
            foreach ($matches[1] as $modLabel) {
                $extraId = mysqli_real_escape_string($conn, strtolower(str_replace(' ', '_', $modLabel)));
                $extraIngRes = mysqli_query($conn, "SELECT ingredient_id, quantity FROM extra_ingredients WHERE extra_id = '$extraId'");
                while ($extraIng = mysqli_fetch_assoc($extraIngRes)) {
                    $ingId = (int)$extraIng['ingredient_id'];
                    $reqQty = (int)$extraIng['quantity'] * $quantity;
                    if (!isset($ingredientDeductions[$ingId])) $ingredientDeductions[$ingId] = 0;
                    $ingredientDeductions[$ingId] += $reqQty;
                }
            }
        }

        // Log the order
        $totalPrice = $unitPrice * $quantity;
        $stmt = mysqli_prepare($conn,
            "INSERT INTO order_logs (product_name, product_id, quantity, unit_price, total_price, customization_notes, processed_by, user_id, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())"
        );
        mysqli_stmt_bind_param($stmt, "siiddssi",
            $product['name'],
            $productId,
            $quantity,
            $unitPrice,
            $totalPrice,
            $notes,
            $userName,
            $userId
        );
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }

    // 2. Validate and deduct all ingredient stocks
    foreach ($ingredientDeductions as $ingId => $deductQty) {
        $checkRes = mysqli_query($conn, "SELECT name, stock FROM products WHERE id=$ingId FOR UPDATE");
        $ingData = mysqli_fetch_assoc($checkRes);
        if (!$ingData) {
            throw new Exception("Ingredient not found (ID: $ingId).");
        }
        if ($ingData['stock'] < $deductQty) {
            throw new Exception("Insufficient ingredient: {$ingData['name']}. Available: {$ingData['stock']}, Required: $deductQty.");
        }
        mysqli_query($conn, "UPDATE products SET stock = stock - $deductQty WHERE id=$ingId");
    }

    mysqli_commit($conn);

    // 3. Recompute available servings for all menu products and return to frontend
    $recomputeRes = mysqli_query($conn, "
        SELECT p.id,
            COALESCE(
                (SELECT MIN(FLOOR(ing.stock / pi.quantity))
                 FROM product_ingredients pi
                 JOIN products ing ON pi.ingredient_id = ing.id
                 WHERE pi.product_id = p.id),
                p.stock
            ) AS stock
        FROM products p
        JOIN categories c ON p.category_id = c.id
        WHERE LOWER(c.name) != 'ingredient'
    ");
    $updatedStock = [];
    while ($row = mysqli_fetch_assoc($recomputeRes)) {
        $updatedStock[] = ['id' => (int)$row['id'], 'stock' => (int)$row['stock']];
    }

    echo json_encode([
        'success' => true,
        'updated_stock' => $updatedStock
    ]);

} catch (Exception $e) {
    mysqli_rollback($conn);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
