

-- =========================================
-- 1. USERS TABLE
-- =========================================
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('owner', 'staff') NOT NULL DEFAULT 'staff',
    status ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO users (name, email, password, role, status) VALUES 
('System Administrator', 'admin@goodvibescafe.com', 'admin123', 'owner', 'Active'),
('Staff Member', 'staff@goodvibescafe.com', 'staff123', 'staff', 'Active');

-- =========================================
-- 2. CATEGORIES TABLE
-- =========================================
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO categories (name) VALUES 
('Coffee'),
('Snack'),
('Beverage'),
('Meal'),
('Ingredient');

-- =========================================
-- 3. PRODUCTS TABLE
-- =========================================
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    category_id INT NOT NULL,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    stock INT NOT NULL DEFAULT 0,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Menu Products (Category IDs: 1=Coffee, 2=Snack, 3=Beverage, 4=Meal)
INSERT INTO products (name, category_id, price, stock) VALUES 
-- Coffee (ID 1-4)
('Hot Americano', 1, 100.00, 0),
('Iced Latte', 1, 120.00, 0),
('Caramel Macchiato', 1, 140.00, 0),
('Spanish Latte', 1, 150.00, 0),
-- Snack (ID 5-8)
('Potato Fries', 2, 80.00, 0),
('Cheese Nachos', 2, 95.00, 0),
('Onion Rings', 2, 85.00, 0),
('Classic Cheeseburger', 2, 130.00, 0),
-- Beverage (ID 9-11)
('Iced Peach Tea', 3, 90.00, 0),
('Lemonade', 3, 85.00, 0),
('Matcha Frappe', 3, 160.00, 0),
-- Meal (ID 12-14)
('Tapsilog', 4, 150.00, 0),
('Chicken Wings & Rice', 4, 180.00, 0),
('Pork Sisig w/ Rice', 4, 160.00, 0);

-- Ingredient Items (Category 5=Ingredient) (ID 15-30)
INSERT INTO products (name, category_id, price, stock) VALUES 
('Ground Coffee Beans', 5, 0, 200),
('Milk', 5, 0, 150),
('Caramel Syrup', 5, 0, 80),
('Sugar', 5, 0, 300),
('Potato', 5, 0, 100),
('Cooking Oil', 5, 0, 200),
('Nacho Chips', 5, 0, 60),
('Cheese Sauce', 5, 0, 80),
('Onion', 5, 0, 40),
('Breading Mix', 5, 0, 80),
('Beef Patty', 5, 0, 50),
('Burger Bun', 5, 0, 50),
('Peach Tea Powder', 5, 0, 50),
('Lemon', 5, 0, 60),
('Matcha Powder', 5, 0, 40),
('Rice', 5, 0, 200),
('Tapa Beef', 5, 0, 40),
('Egg', 5, 0, 100),
('Chicken Wings', 5, 0, 60),
('Pork Sisig', 5, 0, 50),
('Sauce', 5, 0, 120),
('Ice', 5, 0, 500),
('Condensed Milk', 5, 0, 60);

-- =========================================
-- 3.5. RECIPE TABLES (Ingredients)
-- =========================================

-- Links products to their required ingredients
CREATE TABLE product_ingredients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    ingredient_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (ingredient_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE KEY unique_product_ingredient (product_id, ingredient_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Links POS extra modifiers to required ingredients
CREATE TABLE extra_ingredients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    extra_id VARCHAR(50) NOT NULL,
    ingredient_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    FOREIGN KEY (ingredient_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE KEY unique_extra_ingredient (extra_id, ingredient_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =========================================
-- PRODUCT RECIPES (product_id, ingredient_id, qty)
-- =========================================

-- Hot Americano (1): 1 Ground Coffee, 1 Sugar
INSERT INTO product_ingredients (product_id, ingredient_id, quantity) VALUES
(1, 15, 1), (1, 18, 1);

-- Iced Latte (2): 1 Ground Coffee, 1 Milk, 1 Sugar, 1 Ice
INSERT INTO product_ingredients (product_id, ingredient_id, quantity) VALUES
(2, 15, 1), (2, 16, 1), (2, 18, 1), (2, 36, 1);

-- Caramel Macchiato (3): 1 Ground Coffee, 1 Milk, 1 Caramel Syrup, 1 Ice
INSERT INTO product_ingredients (product_id, ingredient_id, quantity) VALUES
(3, 15, 1), (3, 16, 1), (3, 17, 1), (3, 36, 1);

-- Spanish Latte (4): 1 Ground Coffee, 1 Condensed Milk, 1 Milk, 1 Ice
INSERT INTO product_ingredients (product_id, ingredient_id, quantity) VALUES
(4, 15, 1), (4, 37, 1), (4, 16, 1), (4, 36, 1);

-- Potato Fries (5): 2 Potato, 1 Cooking Oil, 1 Sauce
INSERT INTO product_ingredients (product_id, ingredient_id, quantity) VALUES
(5, 19, 2), (5, 20, 1), (5, 35, 1);

-- Cheese Nachos (6): 1 Nacho Chips, 1 Cheese Sauce
INSERT INTO product_ingredients (product_id, ingredient_id, quantity) VALUES
(6, 21, 1), (6, 22, 1);

-- Onion Rings (7): 1 Onion, 1 Breading Mix, 1 Cooking Oil
INSERT INTO product_ingredients (product_id, ingredient_id, quantity) VALUES
(7, 23, 1), (7, 24, 1), (7, 20, 1);

-- Classic Cheeseburger (8): 1 Beef Patty, 1 Burger Bun, 1 Cheese Sauce, 1 Sauce
INSERT INTO product_ingredients (product_id, ingredient_id, quantity) VALUES
(8, 25, 1), (8, 26, 1), (8, 22, 1), (8, 35, 1);

-- Iced Peach Tea (9): 1 Peach Tea Powder, 1 Sugar, 1 Ice
INSERT INTO product_ingredients (product_id, ingredient_id, quantity) VALUES
(9, 27, 1), (9, 18, 1), (9, 36, 1);

-- Lemonade (10): 1 Lemon, 1 Sugar, 1 Ice
INSERT INTO product_ingredients (product_id, ingredient_id, quantity) VALUES
(10, 28, 1), (10, 18, 1), (10, 36, 1);

-- Matcha Frappe (11): 1 Matcha Powder, 1 Milk, 1 Ice
INSERT INTO product_ingredients (product_id, ingredient_id, quantity) VALUES
(11, 29, 1), (11, 16, 1), (11, 36, 1);

-- Tapsilog (12): 1 Tapa Beef, 1 Rice, 1 Egg
INSERT INTO product_ingredients (product_id, ingredient_id, quantity) VALUES
(12, 31, 1), (12, 30, 1), (12, 32, 1);

-- Chicken Wings & Rice (13): 2 Chicken Wings, 1 Rice, 1 Sauce
INSERT INTO product_ingredients (product_id, ingredient_id, quantity) VALUES
(13, 33, 2), (13, 30, 1), (13, 35, 1);

-- Pork Sisig w/ Rice (14): 1 Pork Sisig, 1 Rice, 1 Egg
INSERT INTO product_ingredients (product_id, ingredient_id, quantity) VALUES
(14, 34, 1), (14, 30, 1), (14, 32, 1);

-- =========================================
-- EXTRA MODIFIER RECIPES (extra_id, ingredient_id, qty)
-- =========================================
-- Extra Shot => 1 Ground Coffee Beans
INSERT INTO extra_ingredients (extra_id, ingredient_id, quantity) VALUES ('extra_shot', 15, 1);
-- Upsize => price increase only, no ingredient deduction
-- Extra Rice => 1 Rice
INSERT INTO extra_ingredients (extra_id, ingredient_id, quantity) VALUES ('extra_rice', 30, 1);
-- Extra Sauce => 1 Sauce
INSERT INTO extra_ingredients (extra_id, ingredient_id, quantity) VALUES ('extra_sauce', 35, 1);

-- =========================================
-- 4. ORDER LOGS TABLE (New Transaction System)
-- =========================================
CREATE TABLE order_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(255) NOT NULL,
    product_id INT DEFAULT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    customization_notes TEXT DEFAULT NULL,
    processed_by VARCHAR(255) NOT NULL,
    user_id INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert realistic sample orders for the logs page
INSERT INTO order_logs (product_name, product_id, quantity, unit_price, total_price, customization_notes, processed_by, user_id, created_at) VALUES 
('Hot Americano', 1, 1, 100.00, 100.00, '', 'System Administrator', 1, DATE_SUB(NOW(), INTERVAL 2 DAY)),
('Iced Latte', 2, 2, 120.00, 240.00, '[Upsize] - extra syrup', 'Staff Member', 2, DATE_SUB(NOW(), INTERVAL 2 DAY)),
('Potato Fries', 5, 1, 80.00, 80.00, '[Extra Sauce]', 'Staff Member', 2, DATE_SUB(NOW(), INTERVAL 1 DAY)),
('Tapsilog', 12, 1, 150.00, 150.00, '[Extra Rice]', 'System Administrator', 1, DATE_SUB(NOW(), INTERVAL 1 DAY)),
('Classic Cheeseburger', 8, 2, 130.00, 260.00, '- No onions on one', 'Staff Member', 2, DATE_SUB(NOW(), INTERVAL 5 HOUR)),
('Matcha Frappe', 11, 1, 160.00, 160.00, '', 'System Administrator', 1, DATE_SUB(NOW(), INTERVAL 2 HOUR)),
('Spanish Latte', 4, 1, 150.00, 150.00, '[Extra Shot]', 'Staff Member', 2, DATE_SUB(NOW(), INTERVAL 30 MINUTE)),
('Chicken Wings & Rice', 13, 1, 180.00, 180.00, '[Extra Sauce]', 'Staff Member', 2, NOW());
